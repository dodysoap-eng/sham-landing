import { useLocalSearchParams } from "expo-router";
import { AppScreen } from "@/components/sham-ui";
import { FormulaEditor } from "@/components/formula-editor";

export default function CalculatorScreen() {
  const params = useLocalSearchParams<{ formulaId?: string }>();
  const formulaId = Array.isArray(params.formulaId) ? params.formulaId[0] : params.formulaId;
  return <AppScreen><FormulaEditor initialFormulaId={formulaId} /></AppScreen>;
}
