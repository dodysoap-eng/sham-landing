import { useEffect, useRef, useState } from "react";
import { Pressable, ScrollView, StyleSheet, Text, TextInput, View } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { Brand } from "@/constants/brand";
import { AppHeader, Button, Card, Notice, Pill, SectionTitle, TextField } from "@/components/sham-ui";
import { IngredientPicker, type PickedMaterial } from "@/components/ingredient-picker";
import { useShamWorkspace } from "@/lib/sham-workspace-context";
import { MARKET_COUNTRIES, searchMarkets } from "@/lib/sham-catalog";
import { PRODUCT_CATEGORIES, calculateFormula, createBlankFormula, createId, formatAmount, type FormulaIngredient, type FormulaRecord, type MethodSession } from "@/lib/sham-domain";
import { confirmAction, showMessage } from "@/lib/ui-notify";

export function FormulaEditor({ initialFormulaId }: { initialFormulaId?: string }) {
  const space = useShamWorkspace();
  const { workspace, syncStatus, cloudConsent, saveFormula, removeFormula, saveSession } = space;
  const [draft, setDraft] = useState<FormulaRecord>(createBlankFormula);
  const appliedInitialId = useRef<string | null>(null);
  const [pickerVisible, setPickerVisible] = useState(false);
  const [marketQuery, setMarketQuery] = useState("");
  const [busy, setBusy] = useState(false);
  useEffect(() => {
    if (!initialFormulaId || appliedInitialId.current === initialFormulaId || !space.ready) return;
    const match = workspace.formulas.find((formula) => formula.id === initialFormulaId);
    if (match) {
      // Intentional: route selection replaces the editable draft after workspace hydration.
      // eslint-disable-next-line react-hooks/set-state-in-effect
      setDraft({ ...match, ingredients: match.ingredients.map((row) => ({ ...row })) });
      appliedInitialId.current = initialFormulaId;
    }
  }, [initialFormulaId, space.ready, workspace.formulas]);
  const calculation = calculateFormula(draft);
  const canSave = draft.title.trim().length > 0 && calculation.totalInput > 0 && draft.ingredients.every((row) => row.amount >= 0) && draft.targetBatchGrams > 0 && draft.concentrationPercent >= 0 && draft.concentrationPercent <= 100 && (draft.inputMode !== "percent" || Math.abs(calculation.totalInput - 100) <= 0.01);

  const update = (patch: Partial<FormulaRecord>) => setDraft((current) => ({ ...current, ...patch }));
  const addMaterial = (material: PickedMaterial) => {
    const row: FormulaIngredient = {
      id: createId("row"),
      catalogRef: material.ref,
      name: material.name,
      cas: material.cas,
      amount: draft.inputMode === "percent" ? 1 : 1,
      ifraMaxPercent: material.ifraMaxPercent,
      ifraStatus: material.ifraStatus,
      ifraSource: material.ifraSource,
      source: material.source,
      costPerKg: material.costPerKg,
      currency: material.currency,
      allergens: material.allergens,
      allergenReviewed: material.allergenReviewed,
      allergenSource: material.allergenSource,
      regionalLimits: material.regionalLimits,
    };
    setDraft((current) => ({ ...current, ingredients: [...current.ingredients, row] }));
  };
  const patchRow = (id: string, patch: Partial<FormulaIngredient>) => {
    setDraft((current) => ({ ...current, ingredients: current.ingredients.map((row) => row.id === id ? { ...row, ...patch } : row) }));
  };
  const toggleMarket = (code: string) => {
    const markets = draft.markets ?? [];
    if (markets.includes(code)) update({ markets: markets.filter((item) => item !== code) });
    else if (markets.length >= 5) showMessage("حد الاختيار", "اختر خمسة أسواق كحد أقصى لتسهيل مراجعتها.");
    else update({ markets: [...markets, code] });
  };
  const save = async () => {
    if (!canSave) {
      showMessage("راجع بيانات التركيبة", draft.inputMode === "percent" ? "أكمل المكونات واجعل مجموع النسب 100٪." : "أضف كمية موجبة لمكوّن واحد على الأقل.");
      return;
    }
    setBusy(true);
    const formula = { ...draft, title: draft.title.trim(), updatedAt: new Date().toISOString() };
    try {
      await saveFormula(formula);
      setDraft(formula);
      showMessage("تم الحفظ", cloudConsent ? "حُفظت النسخة المحلية. حالة المزامنة تظهر في رأس الشاشة." : "حُفظت التركيبة على هذا الجهاز فقط؛ المزامنة غير مفعّلة.");
    } catch {
      showMessage("تعذّر الحفظ السحابي", "احتفظنا بنسخة محلية على هذا الجهاز. تحقّق من الاتصال ثم أعد الحفظ.");
    } finally {
      setBusy(false);
    }
  };
  const saveWorkSession = async () => {
    if (!canSave) {
      showMessage("احفظ التركيبة أولًا", "تحتاج جلسة العمل إلى تركيبة لها مكوّن واحد على الأقل ومجموع صالح.");
      return;
    }
    setBusy(true);
    const formula = { ...draft, title: draft.title.trim(), updatedAt: new Date().toISOString() };
    const session: MethodSession = {
      id: createId("session"),
      title: `جلسة · ${formula.title}`,
      formulaId: formula.id,
      notes: formula.notes,
      status: "active",
      updatedAt: new Date().toISOString(),
    };
    try {
      await saveFormula(formula);
      await saveSession(session);
      showMessage("حُفظت جلسة العمل", "يمكنك العودة إلى التركيبة من مساحة العمل في أي وقت.");
    } catch {
      showMessage("تعذّر إكمال الحفظ", "تحقّق من الاتصال، وحاول الحفظ مرة أخرى.");
    } finally {
      setBusy(false);
    }
  };
  const loadFormula = (formula: FormulaRecord) => setDraft({ ...formula, ingredients: formula.ingredients.map((row) => ({ ...row })) });
  const newFormula = () => setDraft(createBlankFormula());
  const deleteSaved = async (formula: FormulaRecord) => {
    const yes = await confirmAction("حذف التركيبة؟", `سيُحذف «${formula.title}» من مساحة حسابك.`);
    if (yes) await removeFormula(formula.id);
  };
  const duplicate = async (formula: FormulaRecord) => {
    const now = new Date().toISOString();
    const copy: FormulaRecord = { ...formula, id: createId("formula"), title: `${formula.title} · نسخة`, ingredients: formula.ingredients.map((row) => ({ ...row, id: createId("row") })), createdAt: now, updatedAt: now };
    await saveFormula(copy);
    setDraft(copy);
    showMessage("أُنشئت نسخة", "يمكنك تعديل النسخة دون تغيير التركيبة الأصلية.");
  };

  return (
    <>
      <AppHeader title="الحاسبة" subtitle="تركيبتك، محسوبة بوضوح" syncStatus={syncStatus} />
      <View style={styles.titleRow}><View style={{ flex: 1 }}><Text style={styles.eyebrow}>ورقة عمل</Text><Text style={styles.pageTitle}>ابنِ تركيبتك</Text></View><Pressable onPress={newFormula} style={styles.newButton}><Ionicons name="add" size={19} color={Brand.colors.forest} /><Text style={styles.newButtonText}>جديدة</Text></Pressable></View>
      <Card>
        <TextField label="اسم التركيبة" value={draft.title} onChangeText={(title) => update({ title })} placeholder="مثال: ورد وعنبر" maxLength={120} />
        <View><Text style={styles.fieldLabel}>طريقة إدخال المكوّنات</Text><View style={styles.segmentRow}>
          <Pressable onPress={() => update({ inputMode: "parts" })} style={[styles.segment, draft.inputMode === "parts" && styles.segmentActive]}><Text style={[styles.segmentText, draft.inputMode === "parts" && styles.segmentTextActive]}>أجزاء بالوزن</Text></Pressable>
          <Pressable onPress={() => update({ inputMode: "percent" })} style={[styles.segment, draft.inputMode === "percent" && styles.segmentActive]}><Text style={[styles.segmentText, draft.inputMode === "percent" && styles.segmentTextActive]}>نِسَب مئوية</Text></Pressable>
        </View><Text style={styles.fieldHint}>{draft.inputMode === "parts" ? "تُحفظ الأجزاء كما أدخلتها، ويُحسب نصيب كل مادة عند تحجيم الدفعة." : "يجب أن يساوي مجموع النسب 100٪ قبل الحفظ."}</Text></View>
        <View style={styles.numberRow}>
          <TextField containerStyle={styles.numberField} label="حجم الدفعة (غ)" value={String(draft.targetBatchGrams)} keyboardType="decimal-pad" onChangeText={(v) => update({ targetBatchGrams: Number(v.replace(",", ".")) || 0 })} />
          <TextField containerStyle={styles.numberField} label="تركيز المركز في المنتج (%)" value={String(draft.concentrationPercent)} keyboardType="decimal-pad" onChangeText={(v) => update({ concentrationPercent: Number(v.replace(",", ".")) || 0 })} />
        </View>
        <View><Text style={styles.fieldLabel}>فئة المنتج</Text><ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.categoryRow}>
          {PRODUCT_CATEGORIES.map((category) => <Pressable key={category.value} onPress={() => update({ productCategory: category.value })} style={[styles.categoryChip, draft.productCategory === category.value && styles.categoryChipActive]}><Text style={[styles.categoryText, draft.productCategory === category.value && styles.categoryTextActive]}>{category.label}</Text></Pressable>)}
        </ScrollView></View>
        <View style={{ gap: 8 }}><SectionTitle title="الأسواق المستهدفة" detail="أسماء ورموز فقط؛ أدخل حدود الخامات من مصدر حديث في مكتبتك." /><TextField label="ابحث عن بلد/سوق" value={marketQuery} onChangeText={setMarketQuery} placeholder="مثال: مصر أو Saudi أو sa" maxLength={80} /><View style={{ flexDirection: "row-reverse", flexWrap: "wrap", gap: 6 }}>{searchMarkets(marketQuery, 8).map((market) => <Pressable key={market.code} onPress={() => toggleMarket(market.code)} style={[styles.categoryChip, (draft.markets ?? []).includes(market.code) && styles.categoryChipActive]}><Text style={[styles.categoryText, (draft.markets ?? []).includes(market.code) && styles.categoryTextActive]}>{market.ar}</Text></Pressable>)}</View>{(draft.markets ?? []).length ? <View style={{ flexDirection: "row-reverse", flexWrap: "wrap", gap: 6 }}>{(draft.markets ?? []).map((code) => <Pressable key={code} onPress={() => toggleMarket(code)} style={[styles.categoryChip, styles.categoryChipActive]}><Text style={[styles.categoryText, styles.categoryTextActive]}>{MARKET_COUNTRIES.find((item) => item.code === code)?.ar ?? code.toUpperCase()} ×</Text></Pressable>)}</View> : null}</View>
        <SectionTitle title="مكوّنات التركيبة" detail={`${draft.ingredients.length} مكوّن`} />
        {draft.ingredients.length ? <View style={{ gap: 9 }}>
          {draft.ingredients.map((row, index) => <View key={row.id} style={styles.ingredientRow}>
            <Pressable accessibilityLabel={`حذف ${row.name}`} onPress={() => update({ ingredients: draft.ingredients.filter((item) => item.id !== row.id) })} style={styles.removeRow}><Ionicons name="close" size={17} color={Brand.colors.muted} /></Pressable>
            <View style={styles.ingredientInfo}><View style={styles.rowTitle}><Text style={styles.ingredientName}>{row.name}</Text><Pill label={row.ifraStatus === "documented" ? "حد موثّق" : "غير مُقيّم"} tone={row.ifraStatus === "documented" ? "green" : "warning"} /></View><Text style={styles.ingredientMeta}>{row.cas ? `CAS ${row.cas} · ` : ""}{row.costPerKg != null ? `تكلفة ${formatAmount(row.costPerKg)} ${row.currency ?? ""}/كغ · ` : ""}{row.source?.includes("CosIng") ? "مرجع تاريخي" : "مكوّن المستخدم"}</Text></View>
            <View style={styles.amountBox}><Text style={styles.amountLabel}>{draft.inputMode === "parts" ? "جزء" : "%"}</Text><TextInput value={String(row.amount)} onChangeText={(v) => patchRow(row.id, { amount: Number(v.replace(",", ".")) || 0 })} keyboardType="decimal-pad" style={styles.amountInput} selectTextOnFocus /></View>
            <Text style={styles.rowIndex}>{String(index + 1).padStart(2, "0")}</Text>
          </View>)}
        </View> : <View style={styles.emptyIngredients}><Ionicons name="leaf-outline" size={22} color={Brand.colors.muted} /><Text style={styles.emptyText}>أضف أول مادة عطرية لبدء الحساب.</Text></View>}
        <Button label="إضافة مكوّن" icon="add" onPress={() => setPickerVisible(true)} variant="secondary" />
        <TextField label="ملاحظات وجلسة التجربة" value={draft.notes} onChangeText={(notes) => update({ notes })} placeholder="رائحة، انطباع، تعديل تريد مراجعته لاحقًا…" multiline maxLength={4000} />
      </Card>
      <Card style={styles.resultCard}>
        <View style={styles.resultHeader}><View><Text style={styles.resultEyebrow}>النتيجة التقديرية</Text><Text style={styles.resultTitle}>حساب الدفعة</Text></View><View style={styles.resultStamp}><Ionicons name="calculator-outline" size={20} color={Brand.colors.copper} /></View></View>
        <View style={styles.resultMetrics}>
          <ResultValue label="المجموع المدخل" value={`${formatAmount(calculation.totalInput)}${draft.inputMode === "percent" ? "٪" : " ج"}`} />
          <ResultValue label="مركز عطري" value={`${formatAmount(calculation.concentrateGrams)} غ`} />
          <ResultValue label="المذيب المتبقي" value={`${formatAmount(calculation.carrierGrams)} غ`} />
        </View>
        {calculation.rawCostCurrency && calculation.rawCostTotal != null ? <><ResultValue label="تقدير تكلفة الخامات" value={`${formatAmount(calculation.rawCostTotal)} ${calculation.rawCostCurrency}`} /><Text style={styles.fieldHint}>يغطي {calculation.rawCostCoveredRows} من {calculation.rows.length} مكوّن · دون عبوة أو شحن أو ضرائب أو هامش بيع.</Text></> : calculation.rawCostCoveredRows > 0 ? <Notice title="تعذّر جمع تكلفة موحّدة" body="توجد عملات مختلفة بين المواد؛ اختر عملة متسقة قبل مقارنة تقدير التكلفة." tone="info" /> : null}
        <Text style={styles.resultsCaption}>حجم الدفعة {formatAmount(draft.targetBatchGrams)} غ · تركيز {formatAmount(draft.concentrationPercent)}٪</Text>
        {calculation.rows.length ? <View style={styles.scaleList}><Text style={styles.scaleHeading}>مقادير المواد في هذه الدفعة</Text>{calculation.rows.map((row) => <View key={row.id} style={styles.scaleRow}><Text style={styles.scaleValue}>{formatAmount(row.grams)} غ</Text><Text numberOfLines={1} style={styles.scaleName}>{row.name}</Text></View>)}</View> : null}
        {draft.inputMode === "percent" && Math.abs(calculation.totalInput - 100) > 0.01 ? <Notice title="النسب غير مكتملة" body={`المجموع الحالي ${formatAmount(calculation.totalInput)}٪. يلزم 100٪ لحفظ التركيبة كنسب مئوية.`} /> : null}
        {draft.productCategory === "cat4" ? <View style={styles.checkSummary}><Pill label={`${calculation.unknownSafetyCount} دون حد موثّق`} tone="warning" /><Text style={styles.checkText}>IFRA 4 محدود بالحدود المدخلة والموثقة فقط.</Text></View> : <Notice title="هذه الفئة غير مُقيّمة" body="الحاسبة لا تتحقق من IFRA لهذه الفئة. لا تعتمد النتيجة كإقرار سلامة." tone="warning" />}
        {calculation.ifra.some((item) => item.status === "over") ? <Notice title="تجاوز حدًا مدخلًا" body="راجع بيانات المادة والمصدر مع مقيّم سلامة مؤهل قبل أي استخدام." tone="danger" /> : null}
        {calculation.marketChecks.map((check) => { const market = MARKET_COUNTRIES.find((item) => item.code === check.marketCode); const title = `مراجعة سوق ${market?.ar ?? check.marketCode.toUpperCase()}`; const body = check.status === "over" ? `تجاوزت مادة واحدة على الأقل حدًا أدخلته لهذا السوق (${check.overCount} تجاوز). أوقف الاستخدام وراجع الوثيقة والمختص.` : check.status === "unknown" ? `${check.unknownCount} مادة بلا حد سوق موثق. لا يعني غياب البيانات عدم وجود قيود.` : check.status === "partial" ? `البيانات جزئية أو تغطي بعض المواد فقط (${check.partialCount} سجل جزئي). راجع المصدر الحديث.` : "لا يظهر تجاوز ضمن الحدود التي أدخلتها أنت فقط؛ لا تمثل هذه النتيجة تصريحًا قانونيًا."; return <Notice key={check.marketCode} title={title} body={body} tone={check.status === "over" ? "danger" : check.status === "within" ? "info" : "warning"} />; })}
      </Card>
      <View style={styles.actionRow}><Button label="حفظ التركيبة" onPress={save} icon="checkmark" loading={busy} disabled={!canSave} style={{ flex: 1 }} /><Button label="حفظ جلسة" onPress={saveWorkSession} icon="bookmark-outline" variant="secondary" disabled={!canSave || busy} style={{ flex: 1 }} /></View>
      <SectionTitle title="تركيبات محفوظة" detail={`${workspace.formulas.length} في حسابك`} />
      {workspace.formulas.length ? workspace.formulas.slice(0, 20).map((formula) => <SavedFormula key={formula.id} formula={formula} onEdit={() => loadFormula(formula)} onCopy={() => duplicate(formula)} onDelete={() => deleteSaved(formula)} />) : <Text style={styles.noSaved}>لا توجد تركيبات محفوظة بعد. احفظ عملك ليظهر هنا.</Text>}
      <IngredientPicker visible={pickerVisible} onClose={() => setPickerVisible(false)} onSelect={addMaterial} userIngredients={workspace.ingredients} />
    </>
  );
}

function ResultValue({ label, value }: { label: string; value: string }) {
  return <View style={styles.resultValue}><Text style={styles.valueLabel}>{label}</Text><Text style={styles.valueNumber}>{value}</Text></View>;
}
function SavedFormula({ formula, onEdit, onCopy, onDelete }: { formula: FormulaRecord; onEdit: () => void; onCopy: () => void; onDelete: () => void }) {
  return <Card style={styles.savedCard}><View style={styles.savedHead}><Pressable onPress={onDelete} style={styles.savedDelete}><Ionicons name="trash-outline" size={16} color={Brand.colors.danger} /></Pressable><View style={{ flex: 1 }}><Text style={styles.savedTitle}>{formula.title}</Text><Text style={styles.savedMeta}>{formula.ingredients.length} مواد · {formatAmount(formula.targetBatchGrams)} غ · {formatAmount(formula.concentrationPercent)}٪</Text></View><Pill label={formula.productCategory === "cat4" ? "Cat 4" : "غير مُقيّم"} tone={formula.productCategory === "cat4" ? "green" : "warning"} /></View><View style={styles.savedButtons}><Button label="تعديل" onPress={onEdit} icon="create-outline" variant="secondary" style={{ flex: 1 }} /><Button label="نسخ" onPress={onCopy} icon="copy-outline" variant="quiet" style={{ flex: 1 }} /></View></Card>;
}

const styles = StyleSheet.create({
  titleRow: { flexDirection: "row-reverse", alignItems: "center", justifyContent: "space-between" },
  eyebrow: { color: Brand.colors.copper, fontSize: 11, fontWeight: "800", textAlign: "right" },
  pageTitle: { color: Brand.colors.ink, fontSize: 22, fontWeight: "900", textAlign: "right", marginTop: 4 },
  newButton: { flexDirection: "row-reverse", alignItems: "center", backgroundColor: Brand.colors.mint, borderRadius: 14, paddingHorizontal: 12, paddingVertical: 10, gap: 4 },
  newButtonText: { color: Brand.colors.forest, fontSize: 12, fontWeight: "800" },
  fieldLabel: { color: Brand.colors.ink, textAlign: "right", fontSize: 12, fontWeight: "700", marginBottom: 7 },
  fieldHint: { color: Brand.colors.muted, textAlign: "right", fontSize: 10, marginTop: 5, lineHeight: 15 },
  segmentRow: { flexDirection: "row-reverse", padding: 4, backgroundColor: "#F0EEE7", borderRadius: 14, gap: 4 },
  segment: { flex: 1, minHeight: 38, borderRadius: 11, alignItems: "center", justifyContent: "center" },
  segmentActive: { backgroundColor: Brand.colors.forest },
  segmentText: { color: Brand.colors.muted, fontSize: 11, fontWeight: "700" },
  segmentTextActive: { color: Brand.colors.paper },
  numberRow: { flexDirection: "row-reverse", gap: 10 },
  numberField: { flex: 1 },
  categoryRow: { flexDirection: "row-reverse", gap: 7 },
  categoryChip: { backgroundColor: "#F0EEE7", borderRadius: 100, paddingHorizontal: 11, paddingVertical: 8 },
  categoryChipActive: { backgroundColor: Brand.colors.forest },
  categoryText: { color: Brand.colors.muted, fontSize: 10, fontWeight: "700" },
  categoryTextActive: { color: Brand.colors.paper },
  ingredientRow: { flexDirection: "row-reverse", alignItems: "center", gap: 7, borderWidth: 1, borderColor: Brand.colors.line, borderRadius: 15, padding: 9, backgroundColor: "#FCFBF6" },
  removeRow: { width: 28, height: 32, alignItems: "center", justifyContent: "center" },
  ingredientInfo: { flex: 1, alignItems: "flex-end", gap: 5 },
  rowTitle: { alignItems: "flex-end", gap: 4 },
  ingredientName: { color: Brand.colors.ink, textAlign: "right", fontSize: 12, fontWeight: "800" },
  ingredientMeta: { color: Brand.colors.muted, fontSize: 9, textAlign: "right" },
  amountBox: { minWidth: 55, maxWidth: 70, alignItems: "center", backgroundColor: Brand.colors.paper, borderWidth: 1, borderColor: Brand.colors.line, borderRadius: 11, paddingHorizontal: 5, paddingVertical: 3 },
  amountLabel: { color: Brand.colors.muted, fontSize: 8 },
  amountInput: { color: Brand.colors.ink, fontSize: 14, fontWeight: "800", textAlign: "center", minWidth: 45, padding: 2 },
  rowIndex: { color: Brand.colors.copper, fontSize: 9, fontWeight: "800" },
  emptyIngredients: { minHeight: 88, borderWidth: 1, borderStyle: "dashed", borderColor: Brand.colors.line, borderRadius: 15, alignItems: "center", justifyContent: "center", gap: 7 },
  emptyText: { color: Brand.colors.muted, fontSize: 11 },
  resultCard: { backgroundColor: "#F8F6EF" },
  resultHeader: { flexDirection: "row-reverse", alignItems: "center", justifyContent: "space-between" },
  resultEyebrow: { color: Brand.colors.copper, textAlign: "right", fontSize: 10, fontWeight: "800" },
  resultTitle: { color: Brand.colors.ink, textAlign: "right", fontSize: 18, fontWeight: "900", marginTop: 3 },
  resultStamp: { width: 40, height: 40, borderRadius: 14, backgroundColor: Brand.colors.copperPale, alignItems: "center", justifyContent: "center" },
  resultMetrics: { flexDirection: "row-reverse", gap: 8 },
  resultValue: { flex: 1, backgroundColor: Brand.colors.paper, borderRadius: 14, padding: 10, gap: 6 },
  valueLabel: { color: Brand.colors.muted, textAlign: "right", fontSize: 9 },
  valueNumber: { color: Brand.colors.forest, textAlign: "right", fontSize: 14, fontWeight: "900" },
  resultsCaption: { color: Brand.colors.muted, textAlign: "right", fontSize: 10 },
  scaleList: { borderTopWidth: 1, borderTopColor: Brand.colors.line, paddingTop: 10, gap: 7 },
  scaleHeading: { color: Brand.colors.ink, textAlign: "right", fontSize: 11, fontWeight: "800" },
  scaleRow: { flexDirection: "row-reverse", justifyContent: "space-between", gap: 10 },
  scaleName: { flex: 1, color: Brand.colors.muted, textAlign: "right", fontSize: 10 },
  scaleValue: { color: Brand.colors.ink, fontSize: 10, fontWeight: "800" },
  checkSummary: { flexDirection: "row-reverse", alignItems: "center", gap: 8, flexWrap: "wrap" },
  checkText: { flex: 1, textAlign: "right", color: Brand.colors.muted, fontSize: 10 },
  actionRow: { flexDirection: "row-reverse", gap: 8 },
  noSaved: { color: Brand.colors.muted, fontSize: 11, textAlign: "right", lineHeight: 18 },
  savedCard: { padding: 13 },
  savedHead: { flexDirection: "row-reverse", gap: 8, alignItems: "center" },
  savedDelete: { width: 32, height: 32, alignItems: "center", justifyContent: "center" },
  savedTitle: { color: Brand.colors.ink, textAlign: "right", fontWeight: "800", fontSize: 13 },
  savedMeta: { color: Brand.colors.muted, textAlign: "right", fontSize: 10, marginTop: 4 },
  savedButtons: { flexDirection: "row-reverse", gap: 7 },
});
