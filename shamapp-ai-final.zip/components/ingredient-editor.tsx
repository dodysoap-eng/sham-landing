import { useEffect, useMemo, useState } from "react";
import { Modal, Pressable, ScrollView, StyleSheet, Text, View } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import countrySource from "@/data/countries.json";
import { Brand } from "@/constants/brand";
import { Button, Notice, Pill, TextField } from "@/components/sham-ui";
import { createId, normalizeSearch, type RegionalLimit, type WorkspaceIngredient } from "@/lib/sham-domain";
import type { MarketCountry } from "@/lib/sham-catalog";

const countries = countrySource as MarketCountry[];
const currencies = ["EGP", "SAR", "AED", "USD", "EUR", "GBP"];
type Props = { visible: boolean; initial: WorkspaceIngredient | null; onClose: () => void; onSave: (item: WorkspaceIngredient) => void };

function newIngredient(): WorkspaceIngredient {
  return { id: createId("ingredient"), name: "", type: "aroma", ifraStatus: "unknown", ifraMaxPercent: null, regionalLimits: [], allergens: [] };
}

export function IngredientEditor({ visible, initial, onClose, onSave }: Props) {
  const [draft, setDraft] = useState<WorkspaceIngredient>(() => initial ?? newIngredient());
  const [allergensText, setAllergensText] = useState("");
  const [limitSearch, setLimitSearch] = useState("");
  const [selectedMarket, setSelectedMarket] = useState("");
  const [limitStatus, setLimitStatus] = useState<RegionalLimit["status"]>("unknown");
  const [limitMax, setLimitMax] = useState("");
  const [limitSource, setLimitSource] = useState("");
  const [error, setError] = useState("");

  useEffect(() => {
    if (!visible) return;
    const next = initial ? { ...initial, regionalLimits: [...(initial.regionalLimits ?? [])], allergens: [...(initial.allergens ?? [])] } : newIngredient();
    // Intentional: opening the modal or changing its target record starts a fresh editable draft.
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setDraft(next);
    setAllergensText((next.allergens ?? []).join(", "));
    setLimitSearch("");
    setSelectedMarket("");
    setLimitStatus("unknown");
    setLimitMax("");
    setLimitSource("");
    setError("");
  }, [visible, initial]);

  const marketResults = useMemo(() => {
    const q = normalizeSearch(limitSearch);
    return countries.filter((country) => !q || normalizeSearch(`${country.ar} ${country.en} ${country.code}`).includes(q)).slice(0, 8);
  }, [limitSearch]);
  const patch = (value: Partial<WorkspaceIngredient>) => setDraft((current) => ({ ...current, ...value }));
  const addLimit = () => {
    if (!selectedMarket) { setError("اختر بلدًا/سوقًا أولًا."); return; }
    const parsed = limitMax.trim() ? Number(limitMax.replace(",", ".")) : null;
    if (limitMax.trim() && (!Number.isFinite(parsed) || parsed! < 0 || parsed! > 100)) { setError("أدخل حدًا بين 0 و100٪ أو اتركه فارغًا إذا كانت المعلومة جزئية."); return; }
    if (limitStatus === "documented" && (parsed == null || !limitSource.trim())) { setError("الحد الموثق يتطلب نسبة ومصدرًا يمكن الرجوع إليه."); return; }
    const rule: RegionalLimit = { marketCode: selectedMarket, status: limitStatus, maxPercent: parsed, source: limitSource.trim() || undefined };
    patch({ regionalLimits: [...(draft.regionalLimits ?? []).filter((item) => item.marketCode !== selectedMarket), rule] });
    setSelectedMarket(""); setLimitSearch(""); setLimitMax(""); setLimitSource(""); setLimitStatus("unknown"); setError("");
  };
  const save = () => {
    const name = draft.name.trim();
    if (!name) { setError("اسم المكوّن مطلوب."); return; }
    const ifraMax = draft.ifraMaxPercent;
    if (draft.ifraStatus === "documented" && (ifraMax == null || !Number.isFinite(ifraMax) || !draft.ifraSource?.trim())) {
      setError("عند توثيق حد IFRA أدخل النسبة والمصدر معًا."); return;
    }
    const currency = draft.costPerKg == null ? undefined : (draft.currency || "EGP").toUpperCase();
    onSave({ ...draft, name, currency, allergens: allergensText.split(",").map((value) => value.trim()).filter(Boolean) });
  };

  return <Modal visible={visible} animationType="slide" transparent onRequestClose={onClose}>
    <View style={styles.backdrop}>
      <View style={styles.sheet}>
        <View style={styles.handle} />
        <View style={styles.header}><Pressable onPress={onClose} style={styles.close}><Ionicons name="close" size={20} color={Brand.colors.ink} /></Pressable><View style={{ flex: 1 }}><Text style={styles.title}>{initial ? "بيانات المكوّن" : "أضف مكوّنًا"}</Text><Text style={styles.subtitle}>بياناتك ومصادرك تبقى منفصلة عن كتالوج CosIng.</Text></View><Pill label="خاص بك" tone="gold" /></View>
        <ScrollView keyboardShouldPersistTaps="handled" contentContainerStyle={styles.fields}>
          <TextField label="الاسم" value={draft.name} onChangeText={(name) => patch({ name })} placeholder="اسم الخام كما يظهر على عبوة المورد" maxLength={240} />
          <View style={styles.row}><TextField containerStyle={styles.half} label="الاسم الإنجليزي" value={draft.englishName ?? ""} onChangeText={(englishName) => patch({ englishName })} placeholder="INCI / Name" maxLength={240} autoCapitalize="words" /><TextField containerStyle={styles.half} label="CAS (اختياري)" value={draft.cas ?? ""} onChangeText={(cas) => patch({ cas })} placeholder="مثال: 8008-57-9" maxLength={80} autoCapitalize="none" /></View>
          <View style={styles.row}><TextField containerStyle={styles.half} label="المورد" value={draft.supplier ?? ""} onChangeText={(supplier) => patch({ supplier })} placeholder="اسم المورد أو الدرجة" maxLength={240} /><TextField containerStyle={styles.half} label="النوع/الموضع" value={draft.type ?? "aroma"} onChangeText={(type) => patch({ type })} placeholder="مادة عطرية" maxLength={80} /></View>
          <TextField label="تكلفة الخام لكل كيلوجرام" value={draft.costPerKg == null ? "" : String(draft.costPerKg)} onChangeText={(value) => patch({ costPerKg: value.trim() ? Number(value.replace(",", ".")) : null, currency: value.trim() ? (draft.currency || "EGP") : undefined })} placeholder="اختياري؛ تكلفة خام وليست سعر بيع" keyboardType="decimal-pad" hint="يُستخدم فقط لتقدير تكلفة المواد في وزن الدفعة، دون ضرائب أو شحن." />
          {draft.costPerKg != null ? <View style={styles.currencyRow}>{currencies.map((currency) => <Pressable key={currency} onPress={() => patch({ currency })} style={[styles.currencyChip, draft.currency === currency && styles.chipActive]}><Text style={[styles.currencyText, draft.currency === currency && styles.chipTextActive]}>{currency}</Text></Pressable>)}</View> : null}
          <View><Text style={styles.fieldLabel}>مراجعة حد IFRA · Cat 4 فقط</Text><View style={styles.currencyRow}><Pressable onPress={() => patch({ ifraStatus: "unknown", ifraMaxPercent: null, ifraSource: undefined })} style={[styles.statusChip, draft.ifraStatus === "unknown" && styles.chipActive]}><Text style={[styles.currencyText, draft.ifraStatus === "unknown" && styles.chipTextActive]}>غير موثق</Text></Pressable><Pressable onPress={() => patch({ ifraStatus: "documented" })} style={[styles.statusChip, draft.ifraStatus === "documented" && styles.chipActive]}><Text style={[styles.currencyText, draft.ifraStatus === "documented" && styles.chipTextActive]}>حد موثق</Text></Pressable></View></View>
          {draft.ifraStatus === "documented" ? <View style={styles.row}><TextField containerStyle={styles.half} label="الحد الأقصى % w/w" value={draft.ifraMaxPercent == null ? "" : String(draft.ifraMaxPercent)} onChangeText={(v) => patch({ ifraMaxPercent: v.trim() ? Number(v.replace(",", ".")) : null })} placeholder="0–100" keyboardType="decimal-pad" /><TextField containerStyle={styles.half} label="مصدر IFRA" value={draft.ifraSource ?? ""} onChangeText={(ifraSource) => patch({ ifraSource })} placeholder="المعيار/شهادة المورد" maxLength={1000} /></View> : null}
          <TextField label="المواد المسببة للحساسية المسجلة" value={allergensText} onChangeText={setAllergensText} placeholder="اكتب الأسماء وافصل بينها بفاصلة" hint="ضعها من مستندات الخام أو المورد فقط؛ لا يستنتج التطبيق القائمة من الاسم أو CAS." maxLength={2000} />
          <Pressable accessibilityRole="checkbox" accessibilityState={{ checked: Boolean(draft.allergenReviewed) }} onPress={() => patch({ allergenReviewed: !draft.allergenReviewed })} style={styles.checkRow}><View style={[styles.checkbox, draft.allergenReviewed && styles.checkboxActive]}>{draft.allergenReviewed ? <Ionicons name="checkmark" size={13} color={Brand.colors.paper} /> : null}</View><Text style={styles.checkText}>راجعت البيانات مع مستند المصدر</Text></Pressable>
          {draft.allergenReviewed ? <TextField label="مصدر مراجعة الحساسية" value={draft.allergenSource ?? ""} onChangeText={(allergenSource) => patch({ allergenSource })} placeholder="اسم وثيقة المورد/رقمها" maxLength={1000} /> : null}
          <TextField label="المصدر/ملاحظات المادة" value={draft.source ?? ""} onChangeText={(source) => patch({ source })} placeholder="رابط ورقة البيانات أو مرجع المادة" multiline maxLength={1000} />
          <TextField label="ملاحظاتك" value={draft.notes ?? ""} onChangeText={(notes) => patch({ notes })} placeholder="وصف الدرجة أو نتيجة اختبارك…" multiline maxLength={4000} />
          <View style={styles.limitsSection}><Text style={styles.sectionTitle}>حدود سوق أدخلتها أنت</Text><Text style={styles.hint}>ليست قاعدة قوانين عامة. أدخل القيم من وثيقة حديثة محددة، وراجعها لدى مختص.</Text>
            <TextField label="ابحث واختر سوقًا" value={limitSearch} onChangeText={(v) => { setLimitSearch(v); setSelectedMarket(""); }} placeholder="بلد أو رمز ISO" maxLength={80} />
            {selectedMarket ? <Pill label={`السوق المختار · ${countries.find((country) => country.code === selectedMarket)?.ar ?? selectedMarket}`} tone="green" /> : <View style={styles.countryChips}>{marketResults.map((country) => <Pressable key={country.code} onPress={() => { setSelectedMarket(country.code); setError(""); }} style={styles.currencyChip}><Text style={styles.currencyText}>{country.ar}</Text></Pressable>)}</View>}
            {selectedMarket ? <><View style={styles.currencyRow}><StatusChip label="غير مُقيّم" value="unknown" current={limitStatus} onPress={setLimitStatus} /><StatusChip label="جزئي" value="partial" current={limitStatus} onPress={setLimitStatus} /><StatusChip label="موثق" value="documented" current={limitStatus} onPress={setLimitStatus} /></View><TextField label="حد النسبة في المنتج النهائي %" value={limitMax} onChangeText={setLimitMax} placeholder="اختياري إن كانت المعلومة جزئية" keyboardType="decimal-pad" /><TextField label="مصدر قاعدة السوق" value={limitSource} onChangeText={setLimitSource} placeholder="رابط/رقم وثيقة/تاريخ مراجعة" maxLength={1000} /><Button label="إضافة/تحديث الحد" icon="add" variant="secondary" onPress={addLimit} /></> : null}
            {(draft.regionalLimits ?? []).map((rule) => <View key={rule.marketCode} style={styles.limitRow}><Pressable onPress={() => patch({ regionalLimits: (draft.regionalLimits ?? []).filter((item) => item.marketCode !== rule.marketCode) })}><Ionicons name="trash-outline" size={17} color={Brand.colors.danger} /></Pressable><View style={{ flex: 1 }}><Text style={styles.limitName}>{countries.find((country) => country.code === rule.marketCode)?.ar ?? rule.marketCode.toUpperCase()} · {rule.status === "documented" ? `حد ${rule.maxPercent ?? "—"}%` : rule.status === "partial" ? "بيانات جزئية" : "غير مُقيّم"}</Text><Text style={styles.hint}>{rule.source || "لا يوجد مصدر مرفق"}</Text></View></View>)}
          </View>
          {error ? <Notice title="راجع البيانات" body={error} tone="danger" /> : null}
          <View style={styles.actionRow}><Button label="حفظ بيانات المادة" icon="checkmark" onPress={save} style={{ flex: 1 }} /><Button label="إلغاء" variant="quiet" onPress={onClose} style={{ flex: 1 }} /></View>
        </ScrollView>
      </View>
    </View>
  </Modal>;
}

function StatusChip<T extends string>({ label, value, current, onPress }: { label: string; value: T; current: T; onPress: (value: T) => void }) {
  return <Pressable onPress={() => onPress(value)} style={[styles.statusChip, current === value && styles.chipActive]}><Text style={[styles.currencyText, current === value && styles.chipTextActive]}>{label}</Text></Pressable>;
}

const styles = StyleSheet.create({
  backdrop: { flex: 1, backgroundColor: "rgba(12,23,17,0.45)", justifyContent: "flex-end" },
  sheet: { maxHeight: "94%", minHeight: "75%", borderTopLeftRadius: 25, borderTopRightRadius: 25, backgroundColor: Brand.colors.canvas, paddingHorizontal: 18, paddingTop: 10, paddingBottom: 12, gap: 8 },
  handle: { width: 42, height: 4, borderRadius: 4, backgroundColor: "#C8C5BB", alignSelf: "center" },
  header: { flexDirection: "row-reverse", alignItems: "center", gap: 10, paddingVertical: 4 },
  close: { width: 37, height: 37, borderRadius: 13, backgroundColor: Brand.colors.paper, alignItems: "center", justifyContent: "center" },
  title: { color: Brand.colors.ink, fontSize: 16, fontWeight: "900", textAlign: "right" },
  subtitle: { color: Brand.colors.muted, fontSize: 10, lineHeight: 15, textAlign: "right", marginTop: 3 },
  fields: { gap: 13, paddingBottom: 25 },
  row: { flexDirection: "row-reverse", gap: 8 },
  half: { flex: 1 },
  fieldLabel: { color: Brand.colors.ink, fontWeight: "700", fontSize: 12, textAlign: "right", marginBottom: 7 },
  currencyRow: { flexDirection: "row-reverse", gap: 7, flexWrap: "wrap" },
  currencyChip: { borderRadius: 99, borderWidth: 1, borderColor: Brand.colors.line, backgroundColor: Brand.colors.paper, paddingHorizontal: 10, paddingVertical: 7 },
  statusChip: { borderRadius: 99, borderWidth: 1, borderColor: Brand.colors.line, backgroundColor: Brand.colors.paper, paddingHorizontal: 12, paddingVertical: 8 },
  chipActive: { backgroundColor: Brand.colors.forest, borderColor: Brand.colors.forest },
  currencyText: { color: Brand.colors.ink, fontSize: 10, fontWeight: "700" },
  chipTextActive: { color: Brand.colors.paper },
  checkRow: { flexDirection: "row-reverse", alignItems: "center", gap: 9 },
  checkbox: { width: 19, height: 19, borderRadius: 5, borderWidth: 1, borderColor: Brand.colors.muted, alignItems: "center", justifyContent: "center" },
  checkboxActive: { backgroundColor: Brand.colors.forest, borderColor: Brand.colors.forest },
  checkText: { flex: 1, textAlign: "right", color: Brand.colors.ink, fontSize: 11 },
  limitsSection: { gap: 11, backgroundColor: "#F1F0E9", padding: 12, borderRadius: 17 },
  sectionTitle: { textAlign: "right", color: Brand.colors.ink, fontSize: 12, fontWeight: "800" },
  hint: { textAlign: "right", color: Brand.colors.muted, fontSize: 9, lineHeight: 14 },
  countryChips: { flexDirection: "row-reverse", flexWrap: "wrap", gap: 6 },
  limitRow: { flexDirection: "row-reverse", alignItems: "center", gap: 9, backgroundColor: Brand.colors.paper, borderRadius: 12, padding: 9 },
  limitName: { textAlign: "right", color: Brand.colors.ink, fontSize: 10, fontWeight: "700" },
  actionRow: { flexDirection: "row-reverse", gap: 8, paddingTop: 5 },
});
