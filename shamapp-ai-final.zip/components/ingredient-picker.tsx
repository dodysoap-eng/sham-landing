import { useMemo, useState } from "react";
import { Modal, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { Brand } from "@/constants/brand";
import { Button, Pill } from "@/components/sham-ui";
import { CATALOG_ENTRIES, CATALOG_REFERENCE_DATE, searchCatalog, type CatalogEntry } from "@/lib/sham-catalog";
import { createId, normalizeSearch, type RegionalLimit, type WorkspaceIngredient } from "@/lib/sham-domain";

export type PickedMaterial = {
  id: string;
  ref?: string;
  name: string;
  cas?: string;
  source?: string;
  ifraMaxPercent?: number | null;
  ifraStatus: "unknown" | "documented";
  ifraSource?: string;
  costPerKg?: number | null;
  currency?: string;
  allergens?: string[];
  allergenReviewed?: boolean;
  allergenSource?: string;
  regionalLimits?: RegionalLimit[];
};

export function IngredientPicker({ visible, onClose, onSelect, userIngredients = [] }: { visible: boolean; onClose: () => void; onSelect: (entry: PickedMaterial) => void; userIngredients?: WorkspaceIngredient[] }) {
  const [query, setQuery] = useState("");
  const [customName, setCustomName] = useState("");
  const results = useMemo(() => searchCatalog(query, 50), [query]);
  const personalResults = useMemo(() => {
    const q = normalizeSearch(query);
    return userIngredients.filter((item) => !q || normalizeSearch([item.name, item.englishName ?? "", item.cas ?? "", item.supplier ?? ""].join(" ")).includes(q)).slice(0, 25);
  }, [query, userIngredients]);
  const showCustom = customName.trim().length > 0;
  const choose = (entry: CatalogEntry) => {
    onSelect({ id: createId("material"), ref: entry.ref, name: entry.commonName || entry.name, cas: entry.cas, source: entry.identitySource || `CosIng · لقطة 2016 · ref ${entry.ref}`, ifraMaxPercent: null, ifraStatus: "unknown" });
    setQuery(""); setCustomName(""); onClose();
  };
  const choosePersonal = (item: WorkspaceIngredient) => {
    onSelect({ id: createId("material"), ref: item.id, name: item.name, cas: item.cas, source: item.source || item.supplier || "من مكتبتك الخاصة", ifraMaxPercent: item.ifraMaxPercent, ifraStatus: item.ifraStatus, ifraSource: item.ifraSource, costPerKg: item.costPerKg, currency: item.currency, allergens: item.allergens, allergenReviewed: item.allergenReviewed, allergenSource: item.allergenSource, regionalLimits: item.regionalLimits });
    setQuery(""); setCustomName(""); onClose();
  };
  const chooseCustom = () => {
    const name = customName.trim();
    if (!name) return;
    onSelect({ id: createId("material"), name, source: "إدخال المستخدم — لم يُتحقق من الهوية أو السلامة", ifraStatus: "unknown", ifraMaxPercent: null });
    setCustomName(""); setQuery(""); onClose();
  };
  return (
    <Modal visible={visible} animationType="slide" transparent onRequestClose={onClose}>
      <View style={styles.backdrop}>
        <View style={styles.sheet}>
          <View style={styles.handle} />
          <View style={styles.header}><Pressable onPress={onClose} style={styles.close}><Ionicons name="close" size={21} color={Brand.colors.ink} /></Pressable><View style={{ flex: 1 }}><Text style={styles.title}>أضف مكوّنًا</Text><Text style={styles.subtitle}>كتالوج تاريخي + مكتبتك الخاصة</Text></View><View style={styles.count}><Text style={styles.countText}>{CATALOG_ENTRIES.length.toLocaleString("ar-EG")}</Text></View></View>
          <View style={styles.searchBox}><Ionicons name="search-outline" size={18} color={Brand.colors.muted} /><TextInput value={query} onChangeText={setQuery} placeholder="اسم أو مرادف أو CAS أو مورد" placeholderTextColor={Brand.colors.muted} style={styles.searchInput} textAlign="right" autoCapitalize="none" /></View>
          <View style={styles.customRow}><TextInput value={customName} onChangeText={setCustomName} placeholder="أو اكتب اسم مكوّن خاص…" placeholderTextColor={Brand.colors.muted} style={styles.customInput} textAlign="right" /><Button label="إضافة" onPress={chooseCustom} variant="secondary" disabled={!showCustom} style={styles.customButton} /></View>
          <Text style={styles.listTitle}>{query ? `نتائج البحث · ${results.length + personalResults.length}` : `أسماء شائعة في الكتالوج · ${CATALOG_REFERENCE_DATE}`}</Text>
          <ScrollView keyboardShouldPersistTaps="handled" contentContainerStyle={{ gap: 8, paddingBottom: 28 }}>
            {personalResults.length ? <><Text style={styles.personalTitle}>مكوناتك الموثقة في المكتبة</Text>{personalResults.map((item) => <Pressable key={item.id} onPress={() => choosePersonal(item)} style={styles.result}><View style={styles.resultArrow}><Ionicons name="add-circle-outline" size={21} color={Brand.colors.forest} /></View><View style={styles.resultText}><Text style={styles.resultName}>{item.name}</Text><Text style={styles.resultSub}>{[item.cas ? `CAS ${item.cas}` : "", item.supplier ?? "", item.costPerKg != null ? `تكلفة ${item.costPerKg} ${item.currency ?? ""}/كغ` : ""].filter(Boolean).join(" · ") || "مكوّن محفوظ"}</Text><View style={styles.metaRow}><Pill label={item.ifraStatus === "documented" ? "حد IFRA مدخل" : "غير مُقيّم"} tone={item.ifraStatus === "documented" ? "green" : "warning"} /></View></View></Pressable>)}</> : null}
            {results.map((entry) => <Pressable key={entry.ref} onPress={() => choose(entry)} style={({ pressed }) => [styles.result, pressed && { opacity: 0.75 }]}><View style={styles.resultArrow}><Ionicons name="add-circle-outline" size={21} color={Brand.colors.forest} /></View><View style={styles.resultText}><Text style={styles.resultName}>{entry.commonName || entry.name}</Text><Text style={styles.resultSub} numberOfLines={2}>{entry.commonName ? entry.name : entry.description || "مادة عطرية مرجعية"}</Text><View style={styles.metaRow}>{entry.cas ? <Text style={styles.meta}>CAS {entry.cas}</Text> : null}{entry.ref ? <Pill label={`مرجع ${entry.ref}`} /> : null}</View></View></Pressable>)}
            {!results.length && !personalResults.length ? <Text style={styles.noResults}>لا توجد نتائج مطابقة. أضف المادة يدويًا وراجع بيانات المورد.</Text> : null}
          </ScrollView>
          <Text style={styles.sourceNote}>لقطة CosIng تاريخية من 2016؛ الاسم أو CAS لا يثبت هوية درجة المورد أو السلامة أو الوضع القانوني الحالي.</Text>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  backdrop: { flex: 1, backgroundColor: "rgba(14,25,20,0.42)", justifyContent: "flex-end" },
  sheet: { maxHeight: "91%", minHeight: "73%", backgroundColor: Brand.colors.canvas, borderTopLeftRadius: 26, borderTopRightRadius: 26, paddingHorizontal: 18, paddingTop: 9, paddingBottom: 16, gap: 12 },
  handle: { width: 42, height: 4, borderRadius: 5, backgroundColor: "#C8C5BB", alignSelf: "center", marginBottom: 2 },
  header: { flexDirection: "row-reverse", alignItems: "center", gap: 11 },
  close: { width: 38, height: 38, borderRadius: 13, backgroundColor: Brand.colors.paper, alignItems: "center", justifyContent: "center" },
  title: { color: Brand.colors.ink, textAlign: "right", fontWeight: "900", fontSize: 17 },
  subtitle: { color: Brand.colors.muted, textAlign: "right", fontSize: 11, marginTop: 2 },
  count: { borderRadius: 12, backgroundColor: Brand.colors.mint, paddingHorizontal: 10, paddingVertical: 7 },
  countText: { color: Brand.colors.forest, fontSize: 11, fontWeight: "800" },
  searchBox: { flexDirection: "row-reverse", alignItems: "center", gap: 9, borderRadius: 15, borderWidth: 1, borderColor: Brand.colors.line, backgroundColor: Brand.colors.paper, paddingHorizontal: 12 },
  searchInput: { flex: 1, minHeight: 46, color: Brand.colors.ink, fontSize: 13 },
  customRow: { flexDirection: "row-reverse", gap: 8 },
  customInput: { flex: 1, borderWidth: 1, borderColor: Brand.colors.line, borderRadius: 14, backgroundColor: Brand.colors.paper, color: Brand.colors.ink, paddingHorizontal: 12, minHeight: 44, fontSize: 12 },
  customButton: { minHeight: 44, paddingHorizontal: 14 },
  listTitle: { color: Brand.colors.ink, fontSize: 12, fontWeight: "800", textAlign: "right", marginTop: 1 },
  personalTitle: { textAlign: "right", color: Brand.colors.copper, fontSize: 10, fontWeight: "800", marginTop: 4 },
  result: { flexDirection: "row-reverse", alignItems: "center", gap: 10, backgroundColor: Brand.colors.paper, borderWidth: 1, borderColor: Brand.colors.line, borderRadius: 15, padding: 12 },
  resultArrow: { width: 32, alignItems: "center" },
  resultText: { flex: 1, alignItems: "flex-end", gap: 3 },
  resultName: { color: Brand.colors.ink, fontSize: 12, fontWeight: "800", textAlign: "right" },
  resultSub: { color: Brand.colors.muted, fontSize: 10, textAlign: "right", lineHeight: 15 },
  metaRow: { flexDirection: "row-reverse", alignItems: "center", gap: 6, marginTop: 2 },
  meta: { color: Brand.colors.muted, fontSize: 9 },
  noResults: { color: Brand.colors.muted, fontSize: 12, textAlign: "center", padding: 20, lineHeight: 19 },
  sourceNote: { color: Brand.colors.muted, fontSize: 9, textAlign: "right", lineHeight: 14, borderTopWidth: 1, borderTopColor: Brand.colors.line, paddingTop: 8 },
});
