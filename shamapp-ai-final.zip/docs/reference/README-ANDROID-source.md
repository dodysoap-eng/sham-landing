# شم · حاسبة العطور — تحويل Android

> **شم** هو تطبيق ويب (ملف HTML واحد 1.4 MB) يقدّم حاسبة تركيبات العطور مع كتالوج CosIng، تنبيهات IFRA الموثّقة، ومحاكاة الفاتورة حسب السوق.
> هذا المجلد يحوي كل ما يلزم لتحويل التطبيق إلى AAB قابل للنشر على Google Play.

---

## البنية

```
miyaar-android/
├── www/                           ← محتوى الموقع الذي يستضيفه الـ WebView
│   ├── index.html                 ← نسخة من Miyaar-standalone.html
│   ├── manifest.webmanifest       ← PWA manifest (للاستضافة)
│   ├── assetlinks.json            ← Digital Asset Links (للـTWA / intent filter)
│   ├── icons/                     ← 192/512/maskable PNG + SVG
│   └── _headers                   ← Netlify / Cloudflare Pages headers
│
├── scripts/
│   ├── copy-standalone.js         ← ينسخ Miyaar-standalone.html إلى www/index.html
│   ├── build-android.sh            ← بناء كامل محلي (Linux/Mac/WSL)
│   ├── deploy-netlify.sh          ← رفع مجهول إلى Netlify Drop
│   ├── deploy-firebase.sh         ← رفع إلى Firebase Hosting
│   ├── deploy-github-pages.sh     ← رفع إلى gh-pages
│   ├── print-sha256-fingerprint.js← يستخرج SHA256 من keystore ويحدّث assetlinks.json
│   └── play-upload-hint.js        ← طباعة خطوات رفع AAB على Play
│
├── .github/workflows/build-android.yml ← بناء تلقائي + artefact
├── capacitor.config.json          ← Capacitor appId/webDir
├── firebase.json                  ← Firebase Hosting config
├── package.json                   ← npm scripts
└── android/                       ← يولَّد عبر `npx cap add android`
```

---

## المسار الكامل من الصفر إلى Play

### 1) تجهيز البيئة (مرة واحدة على جهازك)

```bash
# macOS عبر Homebrew
brew install node@20 openjdk@17
brew install --cask android-commandlinetools
export ANDROID_HOME="$HOME/Library/Android/sdk"
export PATH="$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools:$PATH"
yes | sdkmanager --licenses
sdkmanager "platform-tools" "platforms;android-34" "build-tools;34.0.0"
```

```bash
# Ubuntu / WSL
sudo apt install -y nodejs npm openjdk-17-jdk unzip
mkdir -p "$HOME/Android/sdk/cmdline-tools"
cd "$HOME/Android/sdk/cmdline-tools"
curl -L -o cmd.zip https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip
unzip cmd.zip && mv cmdline-tools latest && rm cmd.zip
export ANDROID_HOME="$HOME/Android/sdk"
export PATH="$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools:$PATH"
yes | sdkmanager --licenses
sdkmanager "platform-tools" "platforms;android-34" "build-tools;34.0.0"
```

### 2) بناء APK محلي

```bash
cd miyaar-android
# ضع Miyaar-standalone.html في ../Miyaar-standalone.html
# (نفس الملف المستخدم في المعاينة الحية، 1.4 MB)
npm install
npx cap add android     # مرة واحدة فقط
npm run android:build   # ينتج app-release.aab في android/app/build/outputs/bundle/release/
```

> **ملاحظة**: إذا كانت النسخة الأولى غير موقّعة، استبدل الـkeystore:
> ```bash
> keytool -genkeypair -v \
>   -keystore android/app/sham.keystore \
>   -alias sham \
>   -keyalg RSA -keysize 4096 -validity 25000 \
>   -storepass 'كلمة-سر-قوية' -keypass 'كلمة-سر-قوية' \
>   -dname "CN=Sham, O=Your Name, C=EG"
> ```
>
> **مشكلة معروفة وحلّها**: Gradle يفسّر مسار keystore نسبةً لـ`~/.gradle/daemon/<version>/` بدلًا من مجلد المشروع. الحل: مرّر **مسارًا مطلقًا** عبر `-Pandroid.injected.signing.store.file=$PWD/android/app/sham.keystore`. السكربت `scripts/build-android.sh` يفعل ذلك تلقائيًا.

### 3) استخراج SHA256 Fingerprint لتعبئة assetlinks.json

```bash
node scripts/print-sha256-fingerprint.js android/app/sham.keystore sham
# أدخل كلمة السر عندما يُطلب
# السكربت يكتب الـSHA256 داخل www/assetlinks.json تلقائيًا
```

### 4) رفع الموقع على استضافة HTTPS مجانية

اختر واحدًا:

**Netlify Drop** (بدون حساب، لكن الـURL مؤقت):
```bash
bash scripts/deploy-netlify.sh
```

**Netlify CLI** (مع حسابك):
```bash
npm i -g netlify-cli
netlify login
netlify deploy --prod --dir=www
```

**Firebase Hosting**:
```bash
npm i -g firebase-tools
firebase login
# عدّل .firebaserc وضع projectId الخاص بك
firebase use --add
bash scripts/deploy-firebase.sh
```

**GitHub Pages**:
```bash
gh auth login
bash scripts/deploy-github-pages.sh
```

### 5) Play Console

```bash
node scripts/play-upload-hint.js    # يطبع الخطوات المفصّلة
```

رفع الـAAB: `android/app/build/outputs/bundle/release/app-release.aab`

### 6) بناء تلقائي عبر GitHub Actions (اختياري)

1. أنشئ repo على GitHub ودفع هذا المجلد (`miyaar-android/`) إليه.
2. Base64-encode keystore:
   ```bash
   base64 -w 0 android/app/sham.keystore | pbcopy   # macOS
   base64 -w 0 android/app/sham.keystore | xclip    # Linux
   ```
3. في GitHub → Settings → Secrets:
   - `SHAM_KEYSTORE_BASE64` = محتوى base64
   - `SHAM_KEYSTORE_PASS` = كلمة سر الـstore
   - `SHAM_KEY_ALIAS` = `sham`
   - `SHAM_KEY_PASS` = كلمة سر المفتاح
4. ادفع الكود، اذهب إلى Actions → `Build Android (AAB)` → Run workflow.
5. بعد اكتمال البناء، اذهب إلى Artifacts → حمّل `sham-app-release.aab` وارفعه على Play Console يدويًا.

---

## استكشاف الأخطاء

| المشكلة | السبب | الحل |
|---------|------|-----|
| `JAVA_HOME not set` | لم تُضف JAVA_HOME | `export JAVA_HOME=$(/usr/libexec/java_home -v 17)` (macOS) أو `export JAVA_HOME=/usr/lib/jvm/java-17-openjdk-amd64` (Ubuntu) |
| `SDK location not found` | ANDROID_HOME غير معرّف | `export ANDROID_HOME=$HOME/Android/sdk` |
| `Execution failed for task ':capacitor-cordova-android-plugins:processDebugResources'` | Capacitor يحتاج plugins لا تتوفر محليًا | احذف `android/capacitor-cordova-android-plugins/` وأعد `npx cap sync` |
| `assetlinks.json returns 404` | الاستضافة لا تنشر الملف | تأكد أن `www/assetlinks.json` موجود، أعد النشر |
| التطبيق يفتح الموقع الخارجي بدل التطبيق | Digital Asset Links غير موقّعة أو fingerprint خاطئ | تأكد أن الـSHA256 في `www/assetlinks.json` يطابق fingerprint الـkeastore الذي وُقّع به الـAAB |

---

## بيانات الاعتماد الحساسة

| أين | ماذا | لماذا |
|-----|------|-------|
| `android/app/sham.keystore` | ملف Keystore لتوقيع التطبيق | Play يستخدمه للتأكد أن التحديثات من نفس المطوّر |
| `KEYSTORE_PASS` و `KEY_PASS` | كلمتا سر | حماية الـkeystore |
| `SHA256 fingerprint` | بصمة الشهادة | تُكتب في `assetlinks.json` لربط التطبيق بالاستضافة |
| `Play Console` حساب | حساب Google | للنشر على Play (25$ مرة واحدة) |

**لا تشارك keystore أو كلمات السر مع أحد، ولا تضعها في الكود المرفوع لـGitHub.**
**GitHub Actions يخزّنها مشفّرة في Secrets.**