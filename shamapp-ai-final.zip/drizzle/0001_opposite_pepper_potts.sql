CREATE TABLE `userWorkspaces` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`payload` json NOT NULL,
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `userWorkspaces_id` PRIMARY KEY(`id`),
	CONSTRAINT `user_workspaces_user_id_unique` UNIQUE(`userId`)
);
--> statement-breakpoint
ALTER TABLE `userWorkspaces` ADD CONSTRAINT `userWorkspaces_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;