import catalogSource from "@/data/catalog.json";
import formulaSource from "@/data/formulas.json";
import referenceSource from "@/data/perfumery-reference.json";
import countrySource from "@/data/countries.json";
import { normalizeSearch } from "@/lib/sham-domain";

export type CatalogEntry = {
  ref: string;
  name: string;
  commonName?: string;
  englishName?: string;
  cas?: string;
  ec?: string;
  description?: string;
  function?: string;
  sourceRowDate?: string;
  aliases: string[];
  typeHint?: string;
  identitySource?: string;
  identitySourceUrl?: string;
  odorProfile?: string;
  odorSource?: string;
  suggestedLayer?: string;
};

export type SourceFormula = {
  id: string;
  title: string;
  type?: string;
  unit?: string;
  ingredients?: Array<{ name?: string; parts?: number | string; unit?: string; cas?: string; note?: string }>;
  source?: string;
  url?: string;
  note?: string;
  description?: string;
  ratio?: unknown;
  [key: string]: unknown;
};

export type MarketCountry = { code: string; en: string; ar: string };

const catalog = catalogSource as Array<Record<string, unknown>>;
const reference = referenceSource as unknown as {
  overlaysByCosIngRef?: Record<string, Record<string, unknown>>;
  entries?: Array<Record<string, unknown>>;
  starterById?: Record<string, Record<string, unknown>>;
};
const overlays = reference.overlaysByCosIngRef ?? {};
const entryByRef = new Map((reference.entries ?? []).map((entry) => [String(entry.ref ?? ""), entry]));
const starterById = reference.starterById ?? {};
const formulaPack = formulaSource as { version: number; provenance: string; notes: string[]; formulas: SourceFormula[] };

export const SOURCE_FORMULAS = formulaPack.formulas;
export const SOURCE_FORMULA_NOTES = formulaPack.notes;
export const SOURCE_FORMULA_PROVENANCE = formulaPack.provenance;
export const MARKET_COUNTRIES = countrySource as MarketCountry[];
export const MARKET_COUNTRY_SOURCE = "ISO 3166 · بيانات أسماء ورموز فقط من المصدر المرفق";
export const CATALOG_REFERENCE_DATE = "2016-02-15";
export const CATALOG_SOURCE_URL = "https://github.com/openfoodfacts/openbeautyfacts/blob/develop/cosing/COSING_Ingredients-Fragrance.Inventory_v2.csv";

export const CATALOG_ENTRIES: CatalogEntry[] = catalog.map((raw) => {
  const ref = String(raw.ref ?? "");
  const overlay = overlays[ref] ?? {};
  const entry = entryByRef.get(ref) ?? {};
  const starter = starterById[ref] ?? {};
  const aliases = [
    ...(Array.isArray(overlay.aliases) ? overlay.aliases.map(String) : []),
    ...(Array.isArray(entry.aliases) ? entry.aliases.map(String) : []),
    ...(Array.isArray(starter.aliases) ? starter.aliases.map(String) : []),
  ];
  const commonName = String(overlay.commonName ?? entry.commonName ?? starter.commonName ?? "");
  const identitySource = String(overlay.identitySource ?? entry.identitySource ?? "");
  const identitySourceUrl = String(overlay.identitySourceUrl ?? entry.identitySourceUrl ?? entry.sourceUrl ?? "");
  return {
    ref,
    name: String(raw.name ?? ""),
    commonName: commonName || undefined,
    englishName: String(entry.englishName ?? "") || undefined,
    cas: String(raw.cas ?? "") || undefined,
    ec: String(raw.ec ?? "") || undefined,
    description: String(raw.description ?? "") || undefined,
    function: String(raw.function ?? "") || undefined,
    sourceRowDate: String(raw.sourceRowDate ?? "") || undefined,
    aliases: [...new Set(aliases)],
    typeHint: String(overlay.typeHint ?? raw.typeHint ?? "") || undefined,
    identitySource: identitySource || undefined,
    identitySourceUrl: identitySourceUrl || undefined,
    odorProfile: String(entry.odorProfile ?? "") || undefined,
    odorSource: String(entry.odorSource ?? "") || undefined,
    suggestedLayer: String(overlay.suggestedLayer ?? raw.suggestedLayer ?? "") || undefined,
  };
});

export function searchCatalog(query: string, limit = 60): CatalogEntry[] {
  const normalized = normalizeSearch(query);
  if (!normalized) return CATALOG_ENTRIES.slice(0, limit);
  const tokens = normalized.split(" ").filter(Boolean);
  return CATALOG_ENTRIES
    .map((entry) => {
      const haystack = normalizeSearch([
        entry.name,
        entry.commonName ?? "",
        entry.englishName ?? "",
        entry.cas ?? "",
        entry.ec ?? "",
        entry.description ?? "",
        ...entry.aliases,
      ].join(" "));
      let score = 0;
      for (const token of tokens) {
        if (haystack.includes(token)) score += entry.name.toLowerCase().startsWith(token) ? 3 : 1;
      }
      return { entry, score };
    })
    .filter((item) => item.score > 0)
    .sort((a, b) => b.score - a.score || a.entry.name.localeCompare(b.entry.name))
    .slice(0, limit)
    .map((item) => item.entry);
}

export function searchMarkets(query: string, limit = 8): MarketCountry[] {
  const normalized = normalizeSearch(query);
  if (!normalized) return MARKET_COUNTRIES.filter((country) => ["eg", "sa", "ae", "kw", "qa", "bh", "om"].includes(country.code)).slice(0, limit);
  return MARKET_COUNTRIES.filter((country) => normalizeSearch(`${country.ar} ${country.en} ${country.code}`).includes(normalized)).slice(0, limit);
}
