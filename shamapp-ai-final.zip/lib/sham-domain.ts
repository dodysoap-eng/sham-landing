export type ProductCategory = "cat4" | "cosmetic" | "rinseoff" | "candle" | "diffuser" | "aircare" | "other";
export type RegionalLimitStatus = "documented" | "partial" | "unknown";
export type RegionalLimit = { marketCode: string; status: RegionalLimitStatus; maxPercent?: number | null; source?: string };

export type FormulaIngredient = {
  id: string;
  catalogRef?: string;
  name: string;
  cas?: string;
  amount: number;
  ifraMaxPercent?: number | null;
  ifraStatus: "documented" | "unknown";
  ifraSource?: string;
  source?: string;
  costPerKg?: number | null;
  currency?: string;
  allergens?: string[];
  allergenReviewed?: boolean;
  allergenSource?: string;
  regionalLimits?: RegionalLimit[];
};

export type FormulaRecord = {
  id: string;
  title: string;
  productCategory: ProductCategory;
  inputMode: "parts" | "percent";
  concentrationPercent: number;
  targetBatchGrams: number;
  markets?: string[];
  ingredients: FormulaIngredient[];
  notes: string;
  createdAt: string;
  updatedAt: string;
};

export type WorkspaceIngredient = {
  id: string;
  name: string;
  englishName?: string;
  cas?: string;
  type?: string;
  supplier?: string;
  notes?: string;
  ifraStatus: "unknown" | "documented";
  ifraMaxPercent?: number | null;
  ifraSource?: string;
  source?: string;
  costPerKg?: number | null;
  currency?: string;
  allergens?: string[];
  allergenReviewed?: boolean;
  allergenSource?: string;
  regionalLimits?: RegionalLimit[];
};

export type MethodSession = { id: string; title: string; formulaId?: string; notes: string; status: "active" | "paused" | "complete"; updatedAt: string };
export type WorkspaceData = { schemaVersion: 1; updatedAt: string; ingredients: WorkspaceIngredient[]; formulas: FormulaRecord[]; sessions: MethodSession[] };

export type FormulaCalculation = {
  valid: boolean;
  totalInput: number;
  balancePercent: number;
  concentrateGrams: number;
  carrierGrams: number;
  rows: Array<FormulaIngredient & { percentOfConcentrate: number; grams: number; percentOfFinishedProduct: number }>;
  ifra: Array<{ id: string; name: string; status: "within" | "over" | "unknown" | "not_applicable"; finishedPercent: number; maxPercent?: number }>;
  marketChecks: Array<{ marketCode: string; status: "within" | "over" | "partial" | "unknown"; overCount: number; unknownCount: number; partialCount: number }>;
  rawCostTotal: number | null;
  rawCostCurrency: string | null;
  rawCostCoveredRows: number;
  unknownSafetyCount: number;
  warnings: string[];
};

export const PRODUCT_CATEGORIES: Array<{ value: ProductCategory; label: string; evaluated: boolean }> = [
  { value: "cat4", label: "عطر جلدي · IFRA 4", evaluated: true },
  { value: "cosmetic", label: "مستحضر تجميل معطّر", evaluated: false },
  { value: "rinseoff", label: "صابون أو منتج يُشطف", evaluated: false },
  { value: "candle", label: "شمعة معطّرة", evaluated: false },
  { value: "diffuser", label: "ناشر عطري", evaluated: false },
  { value: "aircare", label: "معطّر جو", evaluated: false },
  { value: "other", label: "منتج آخر · مراجعة يدوية", evaluated: false },
];

export function createId(prefix = "sham"): string {
  return `${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
}

export function createEmptyWorkspace(): WorkspaceData {
  return { schemaVersion: 1, updatedAt: new Date().toISOString(), ingredients: [], formulas: [], sessions: [] };
}

export function createBlankFormula(): FormulaRecord {
  const now = new Date().toISOString();
  return { id: createId("formula"), title: "تركيبة جديدة", productCategory: "cat4", inputMode: "parts", concentrationPercent: 20, targetBatchGrams: 100, markets: [], ingredients: [], notes: "", createdAt: now, updatedAt: now };
}

export function calculateFormula(formula: FormulaRecord): FormulaCalculation {
  const hasNegative = formula.ingredients.some((row) => Number(row.amount) < 0);
  const cleanRows = formula.ingredients.map((row) => ({ ...row, amount: Math.max(0, Number(row.amount) || 0) }));
  const totalInput = cleanRows.reduce((sum, row) => sum + row.amount, 0);
  const balancePercent = formula.inputMode === "percent" ? totalInput : 100;
  const concentrateGrams = (Math.max(0, formula.targetBatchGrams) * Math.max(0, formula.concentrationPercent)) / 100;
  const carrierGrams = Math.max(0, formula.targetBatchGrams - concentrateGrams);
  const divisor = formula.inputMode === "percent" ? 100 : totalInput;
  const rows = cleanRows.map((row) => {
    const percentOfConcentrate = divisor > 0 ? (row.amount / divisor) * 100 : 0;
    const grams = formula.inputMode === "percent" ? concentrateGrams * (row.amount / 100) : totalInput > 0 ? concentrateGrams * (row.amount / totalInput) : 0;
    return { ...row, percentOfConcentrate, grams, percentOfFinishedProduct: formula.targetBatchGrams > 0 ? (grams / formula.targetBatchGrams) * 100 : 0 };
  });

  const ifra = rows.map((row) => {
    if (formula.productCategory !== "cat4") return { id: row.id, name: row.name, status: "not_applicable" as const, finishedPercent: row.percentOfFinishedProduct };
    if (row.ifraStatus !== "documented" || row.ifraMaxPercent == null || !Number.isFinite(row.ifraMaxPercent)) return { id: row.id, name: row.name, status: "unknown" as const, finishedPercent: row.percentOfFinishedProduct };
    return { id: row.id, name: row.name, status: row.percentOfFinishedProduct <= row.ifraMaxPercent ? "within" as const : "over" as const, finishedPercent: row.percentOfFinishedProduct, maxPercent: row.ifraMaxPercent };
  });

  const marketChecks = (formula.markets ?? []).map((marketCode) => {
    let overCount = 0;
    let unknownCount = 0;
    let partialCount = 0;
    for (const row of rows) {
      const limit = row.regionalLimits?.find((entry) => entry.marketCode.toLowerCase() === marketCode.toLowerCase());
      if (!limit || limit.status === "unknown") { unknownCount++; continue; }
      if (limit.status === "partial") partialCount++;
      if (typeof limit.maxPercent === "number" && Number.isFinite(limit.maxPercent) && row.percentOfFinishedProduct > limit.maxPercent) overCount++;
      else if (limit.status === "documented" && (limit.maxPercent == null || !Number.isFinite(limit.maxPercent))) unknownCount++;
    }
    const status = overCount ? "over" as const : unknownCount ? "unknown" as const : partialCount ? "partial" as const : "within" as const;
    return { marketCode, status, overCount, unknownCount, partialCount };
  });

  const pricedRows = rows.filter((row) => typeof row.costPerKg === "number" && Number.isFinite(row.costPerKg) && row.costPerKg >= 0 && Boolean(row.currency?.trim()));
  const currencies = [...new Set(pricedRows.map((row) => row.currency!.trim().toUpperCase()))];
  const rawCostTotal = pricedRows.length && currencies.length === 1 ? pricedRows.reduce((total, row) => total + row.grams * (row.costPerKg ?? 0) / 1000, 0) : null;
  const rawCostCurrency = currencies.length === 1 ? currencies[0]! : null;

  const warnings: string[] = [];
  if (hasNegative) warnings.push("لا تقبل أوزان سالبة؛ راجع مقدار كل مادة.");
  if (totalInput <= 0) warnings.push("أضف كمية موجبة لمكوّن واحد على الأقل.");
  if (formula.targetBatchGrams <= 0) warnings.push("أدخل وزن دفعة أكبر من صفر.");
  if (formula.concentrationPercent < 0 || formula.concentrationPercent > 100) warnings.push("يجب أن يكون تركيز المركز بين 0 و100٪.");
  if (formula.inputMode === "percent" && Math.abs(totalInput - 100) > 0.01) warnings.push(`مجموع النسب ${totalInput.toFixed(2)}٪؛ المطلوب 100٪.`);
  if (formula.productCategory !== "cat4") warnings.push("هذه الفئة غير مُقيّمة في المراجعة المبرمجة؛ النتيجة ليست تقييم سلامة أو اعتمادًا تنظيميًا.");
  else if (ifra.some((item) => item.status === "unknown")) warnings.push("بعض حدود IFRA غير موثّقة لهذه المواد؛ راجع مستندات المورد ومقيّم السلامة.");
  if (ifra.some((item) => item.status === "over")) warnings.push("تجاوزت مادة واحدة على الأقل الحد الموثّق المدخل. أوقف الاستخدام وراجع المصدر والمختص.");
  for (const check of marketChecks) {
    if (check.status === "over") warnings.push(`تجاوزت مادة حدًا مدخلًا لسوق ${check.marketCode.toUpperCase()}; راجع المصدر والمختص.`);
    else if (check.status === "unknown") warnings.push(`لا توجد حدود موثّقة لكل خامات سوق ${check.marketCode.toUpperCase()}؛ لا يعني ذلك عدم وجود قيود.`);
    else if (check.status === "partial") warnings.push(`بيانات سوق ${check.marketCode.toUpperCase()} جزئية؛ راجع اللوائح ومصادر المورد.`);
    else warnings.push(`لا يظهر تجاوز ضمن الحدود التي أدخلتها لسوق ${check.marketCode.toUpperCase()} فقط؛ هذا ليس اعتمادًا قانونيًا.`);
  }
  if (pricedRows.length && pricedRows.length < rows.length) warnings.push("تقدير تكلفة المواد جزئي لعدم إدخال تكلفة لكل المكوّنات.");
  if (currencies.length > 1) warnings.push("توجد عملات مختلفة؛ لم تُجمع التكلفة في رقم واحد.");

  return {
    valid: warnings.every((warning) => !warning.startsWith("لا تقبل") && !warning.startsWith("أضف") && !warning.startsWith("أدخل") && !warning.startsWith("يجب") && !warning.startsWith("مجموع النسب")),
    totalInput, balancePercent, concentrateGrams, carrierGrams, rows, ifra, marketChecks, rawCostTotal, rawCostCurrency, rawCostCoveredRows: pricedRows.length,
    unknownSafetyCount: ifra.filter((item) => item.status === "unknown").length,
    warnings,
  };
}

export function formatAmount(value: number, digits = 2): string {
  if (!Number.isFinite(value)) return "0";
  return value.toLocaleString("ar-EG", { maximumFractionDigits: digits, minimumFractionDigits: 0 });
}

export function normalizeSearch(value: string): string {
  return value.normalize("NFKD").replace(/[\u064B-\u065F\u0670]/g, "").replace(/[أإآ]/g, "ا").replace(/ى/g, "ي").toLowerCase().replace(/[^\p{L}\p{N}]+/gu, " ").trim();
}
