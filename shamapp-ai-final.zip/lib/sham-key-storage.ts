import * as SecureStore from "expo-secure-store";
import { Platform } from "react-native";
import { sha256 } from "@noble/hashes/sha2.js";
import { bytesToHex, hexToBytes } from "@noble/hashes/utils.js";
import { createDeviceKey } from "./sham-sync-crypto";
import { encodeUtf8 } from "./sham-utf8";

const scope = (kind: string, openId: string) => `sham.${kind}.${bytesToHex(sha256(encodeUtf8(openId)).slice(0, 16))}`;

async function readSecret(key: string): Promise<string | null> {
  if (Platform.OS === "web") {
    try { return typeof window === "undefined" ? null : window.localStorage.getItem(key); } catch { return null; }
  }
  try { return await SecureStore.getItemAsync(key); } catch { return null; }
}

async function writeSecret(key: string, value: string): Promise<void> {
  if (Platform.OS === "web") {
    if (typeof window === "undefined") throw new Error("لا يمكن الوصول إلى مخزن المتصفح المحلي.");
    window.localStorage.setItem(key, value);
    return;
  }
  await SecureStore.setItemAsync(key, value);
}

async function removeSecret(key: string): Promise<void> {
  if (Platform.OS === "web") {
    try { window.localStorage.removeItem(key); } catch { /* no browser storage */ }
    return;
  }
  await SecureStore.deleteItemAsync(key).catch(() => undefined);
}

export async function getOrCreateDeviceKey(openId: string): Promise<Uint8Array> {
  const storageKey = scope("device-key.v1", openId);
  const existing = await readSecret(storageKey);
  if (existing && /^[0-9a-f]{64}$/i.test(existing)) return hexToBytes(existing);
  const key = await createDeviceKey();
  await writeSecret(storageKey, bytesToHex(key));
  return key;
}

export async function getCachedCloudKey(openId: string): Promise<Uint8Array | null> {
  const value = await readSecret(scope("cloud-key.v1", openId));
  return value && /^[0-9a-f]{64}$/i.test(value) ? hexToBytes(value) : null;
}

export async function storeCloudKey(openId: string, key: Uint8Array): Promise<void> {
  await writeSecret(scope("cloud-key.v1", openId), bytesToHex(key));
}

export async function clearCloudKey(openId: string): Promise<void> {
  await removeSecret(scope("cloud-key.v1", openId));
}
