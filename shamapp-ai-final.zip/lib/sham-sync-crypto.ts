import { gcm } from "@noble/ciphers/aes.js";
import { pbkdf2Async } from "@noble/hashes/pbkdf2.js";
import { sha256 } from "@noble/hashes/sha2.js";
import { bytesToHex, hexToBytes } from "@noble/hashes/utils.js";
import * as Crypto from "expo-crypto";
import type { WorkspaceData } from "./sham-domain";
import { decodeUtf8, encodeUtf8 } from "./sham-utf8";

export const CLOUD_ENVELOPE_TYPE = "sham.workspace.aes-gcm.v1" as const;
export const LOCAL_ENVELOPE_TYPE = "sham.local.aes-gcm.v1" as const;
export const PBKDF2_ITERATIONS = 210_000;
const KEY_BYTES = 32;
const NONCE_BYTES = 12;
const SALT_BYTES = 16;

export type EncryptedWorkspace = {
  type: typeof CLOUD_ENVELOPE_TYPE;
  algorithm: "AES-256-GCM";
  kdf: "PBKDF2-SHA256";
  iterations: typeof PBKDF2_ITERATIONS;
  salt: string;
  nonce: string;
  ciphertext: string;
  updatedAt: string;
};

export type EncryptedLocalWorkspace = {
  type: typeof LOCAL_ENVELOPE_TYPE;
  nonce: string;
  ciphertext: string;
};

export function isEncryptedWorkspace(value: unknown): value is EncryptedWorkspace {
  if (!value || typeof value !== "object") return false;
  const item = value as Partial<EncryptedWorkspace>;
  return item.type === CLOUD_ENVELOPE_TYPE && item.algorithm === "AES-256-GCM" && item.kdf === "PBKDF2-SHA256" && item.iterations === PBKDF2_ITERATIONS && typeof item.salt === "string" && /^[0-9a-f]{32}$/i.test(item.salt) && typeof item.nonce === "string" && /^[0-9a-f]{24}$/i.test(item.nonce) && typeof item.ciphertext === "string" && item.ciphertext.length >= 32 && item.ciphertext.length <= 3_000_000 && item.ciphertext.length % 2 === 0 && /^[0-9a-f]+$/i.test(item.ciphertext) && typeof item.updatedAt === "string" && item.updatedAt.length <= 80;
}

export function isEncryptedLocalWorkspace(value: unknown): value is EncryptedLocalWorkspace {
  if (!value || typeof value !== "object") return false;
  const item = value as Partial<EncryptedLocalWorkspace>;
  return item.type === LOCAL_ENVELOPE_TYPE && typeof item.nonce === "string" && /^[0-9a-f]{24}$/i.test(item.nonce) && typeof item.ciphertext === "string" && item.ciphertext.length >= 32 && item.ciphertext.length <= 6_000_000 && item.ciphertext.length % 2 === 0 && /^[0-9a-f]+$/i.test(item.ciphertext);
}

export function isWorkspaceData(value: unknown): value is WorkspaceData {
  if (!value || typeof value !== "object" || Array.isArray(value)) return false;
  const item = value as Partial<WorkspaceData>;
  return item.schemaVersion === 1 && typeof item.updatedAt === "string" && item.updatedAt.length > 0 && item.updatedAt.length <= 80 && Number.isFinite(Date.parse(item.updatedAt)) && Array.isArray(item.ingredients) && Array.isArray(item.formulas) && Array.isArray(item.sessions);
}

export function validateRecoveryPhrase(phrase: string): string | null {
  const normalized = phrase.normalize("NFKC").trim();
  if (normalized.length < 16) return "عبارة الاسترداد يجب أن تتكون من 16 حرفًا أو أكثر؛ فضّل عدة كلمات غير مترابطة.";
  if (normalized.length > 256) return "عبارة الاسترداد أطول من الحد المسموح.";
  return null;
}

export async function createDeviceKey(): Promise<Uint8Array> {
  return Crypto.getRandomBytesAsync(KEY_BYTES);
}

export async function createCloudSalt(): Promise<string> {
  return bytesToHex(await Crypto.getRandomBytesAsync(SALT_BYTES));
}

export async function deriveCloudKey(passphrase: string, saltHex: string): Promise<Uint8Array> {
  const validation = validateRecoveryPhrase(passphrase);
  if (validation) throw new Error(validation);
  if (!/^[0-9a-f]{32}$/i.test(saltHex)) throw new Error("بيانات استرداد النسخة السحابية غير صالحة.");
  return pbkdf2Async(sha256, encodeUtf8(passphrase.normalize("NFKC").trim()), hexToBytes(saltHex), { c: PBKDF2_ITERATIONS, dkLen: KEY_BYTES, asyncTick: 20 });
}

function seal(plaintext: string, key: Uint8Array, nonce: Uint8Array, aad: string): Uint8Array {
  return gcm(key, nonce, encodeUtf8(aad)).encrypt(encodeUtf8(plaintext));
}

function open(ciphertext: Uint8Array, key: Uint8Array, nonce: Uint8Array, aad: string): string {
  const bytes = gcm(key, nonce, encodeUtf8(aad)).decrypt(ciphertext);
  return decodeUtf8(bytes);
}

export async function encryptWorkspace(payload: WorkspaceData, key: Uint8Array, salt: string, openId: string): Promise<EncryptedWorkspace> {
  if (!validateWorkspacePayload(payload)) throw new Error("محتوى مساحة العمل غير صالح أو يتجاوز حد التخزين.");
  const nonce = await Crypto.getRandomBytesAsync(NONCE_BYTES);
  const ciphertext = seal(JSON.stringify(payload), key, nonce, `sham:workspace:v1:${openId}`);
  return {
    type: CLOUD_ENVELOPE_TYPE,
    algorithm: "AES-256-GCM",
    kdf: "PBKDF2-SHA256",
    iterations: PBKDF2_ITERATIONS,
    salt,
    nonce: bytesToHex(nonce),
    ciphertext: bytesToHex(ciphertext),
    updatedAt: payload.updatedAt,
  };
}

export function decryptWorkspace(envelope: EncryptedWorkspace, key: Uint8Array, openId: string): WorkspaceData {
  const raw = open(hexToBytes(envelope.ciphertext), key, hexToBytes(envelope.nonce), `sham:workspace:v1:${openId}`);
  const parsed: unknown = JSON.parse(raw);
  if (!validateWorkspacePayload(parsed)) throw new Error("محتوى النسخة السحابية غير صالح أو يتجاوز حد التخزين.");
  return parsed;
}

export async function encryptLocalWorkspace(payload: WorkspaceData, key: Uint8Array, openId: string): Promise<EncryptedLocalWorkspace> {
  if (!validateWorkspacePayload(payload)) throw new Error("محتوى مساحة العمل غير صالح أو يتجاوز حد التخزين.");
  return encryptLocalValue(payload, key, openId);
}

export async function encryptLocalValue(value: unknown, key: Uint8Array, openId: string): Promise<EncryptedLocalWorkspace> {
  const plaintext = JSON.stringify(value);
  if (typeof plaintext !== "string" || encodeUtf8(plaintext).length > 2_500_000) throw new Error("النسخة المحلية أكبر من الحد الآمن للتخزين.");
  const nonce = await Crypto.getRandomBytesAsync(NONCE_BYTES);
  const ciphertext = seal(plaintext, key, nonce, `sham:local:v1:${openId}`);
  return { type: LOCAL_ENVELOPE_TYPE, nonce: bytesToHex(nonce), ciphertext: bytesToHex(ciphertext) };
}

export function decryptLocalWorkspace(envelope: EncryptedLocalWorkspace, key: Uint8Array, openId: string): WorkspaceData {
  const parsed: unknown = decryptLocalValue(envelope, key, openId);
  if (!validateWorkspacePayload(parsed)) throw new Error("النسخة المحلية غير صالحة أو تتجاوز حد التخزين.");
  return parsed;
}

export function decryptLocalValue<T>(envelope: EncryptedLocalWorkspace, key: Uint8Array, openId: string): T {
  const raw = open(hexToBytes(envelope.ciphertext), key, hexToBytes(envelope.nonce), `sham:local:v1:${openId}`);
  return JSON.parse(raw) as T;
}

export function equalWorkspace(a: WorkspaceData, b: WorkspaceData): boolean {
  return bytesToHex(sha256(encodeUtf8(JSON.stringify(a)))) === bytesToHex(sha256(encodeUtf8(JSON.stringify(b))));
}

type RuntimeRecord = Record<string, unknown>;

const isRecord = (value: unknown): value is RuntimeRecord => Boolean(value) && typeof value === "object" && !Array.isArray(value);
const boundedString = (value: unknown, maxLength: number, minLength = 0): value is string => typeof value === "string" && value.length >= minLength && value.length <= maxLength;
const optionalString = (value: unknown, maxLength: number) => value === undefined || boundedString(value, maxLength);
const boundedNumber = (value: unknown, maxAbs = 1_000_000_000_000): value is number => typeof value === "number" && Number.isFinite(value) && Math.abs(value) <= maxAbs;
const optionalNullableNumber = (value: unknown, maxAbs = 1_000_000_000_000) => value === undefined || value === null || boundedNumber(value, maxAbs);
const optionalBoolean = (value: unknown) => value === undefined || typeof value === "boolean";

function validStringArray(value: unknown, maxItems: number, maxLength: number): boolean {
  return value === undefined || Array.isArray(value) && value.length <= maxItems && value.every((item) => boundedString(item, maxLength));
}

function validRegionalLimits(value: unknown): boolean {
  return value === undefined || Array.isArray(value) && value.length <= 100 && value.every((entry) => {
    if (!isRecord(entry)) return false;
    return boundedString(entry.marketCode, 64, 1) && (entry.status === "documented" || entry.status === "partial" || entry.status === "unknown") && optionalNullableNumber(entry.maxPercent, 1_000_000) && optionalString(entry.source, 2_000);
  });
}

function validFormulaIngredient(value: unknown): boolean {
  if (!isRecord(value)) return false;
  return boundedString(value.id, 256, 1) && boundedString(value.name, 500) && boundedNumber(value.amount) &&
    (value.ifraStatus === "documented" || value.ifraStatus === "unknown") &&
    optionalString(value.catalogRef, 256) && optionalString(value.cas, 128) && optionalNullableNumber(value.ifraMaxPercent, 1_000_000) &&
    optionalString(value.ifraSource, 2_000) && optionalString(value.source, 2_000) && optionalNullableNumber(value.costPerKg, 1_000_000_000) &&
    optionalString(value.currency, 16) && validStringArray(value.allergens, 100, 256) && optionalBoolean(value.allergenReviewed) &&
    optionalString(value.allergenSource, 2_000) && validRegionalLimits(value.regionalLimits);
}

function validWorkspaceIngredient(value: unknown): boolean {
  if (!isRecord(value)) return false;
  return boundedString(value.id, 256, 1) && boundedString(value.name, 500) &&
    (value.ifraStatus === "documented" || value.ifraStatus === "unknown") &&
    optionalString(value.englishName, 500) && optionalString(value.cas, 128) && optionalString(value.type, 200) &&
    optionalString(value.supplier, 500) && optionalString(value.notes, 20_000) && optionalNullableNumber(value.ifraMaxPercent, 1_000_000) &&
    optionalString(value.ifraSource, 2_000) && optionalString(value.source, 2_000) && optionalNullableNumber(value.costPerKg, 1_000_000_000) &&
    optionalString(value.currency, 16) && validStringArray(value.allergens, 100, 256) && optionalBoolean(value.allergenReviewed) &&
    optionalString(value.allergenSource, 2_000) && validRegionalLimits(value.regionalLimits);
}

function validFormulaRecord(value: unknown): boolean {
  if (!isRecord(value) || !Array.isArray(value.ingredients) || value.ingredients.length > 500) return false;
  return boundedString(value.id, 256, 1) && boundedString(value.title, 500) &&
    ["cat4", "cosmetic", "rinseoff", "candle", "diffuser", "aircare", "other"].includes(String(value.productCategory)) &&
    (value.inputMode === "parts" || value.inputMode === "percent") && boundedNumber(value.concentrationPercent, 1_000_000) &&
    boundedNumber(value.targetBatchGrams) && validStringArray(value.markets, 100, 64) && value.ingredients.every(validFormulaIngredient) &&
    boundedString(value.notes, 20_000) && boundedString(value.createdAt, 80, 1) && boundedString(value.updatedAt, 80, 1);
}

function validMethodSession(value: unknown): boolean {
  if (!isRecord(value)) return false;
  return boundedString(value.id, 256, 1) && boundedString(value.title, 500) && optionalString(value.formulaId, 256) &&
    boundedString(value.notes, 20_000) && (value.status === "active" || value.status === "paused" || value.status === "complete") &&
    boundedString(value.updatedAt, 80, 1);
}

export function validateWorkspacePayload(value: unknown): value is WorkspaceData {
  if (!isWorkspaceData(value) || value.ingredients.length > 2_000 || value.formulas.length > 500 || value.sessions.length > 500) return false;
  if (!value.ingredients.every(validWorkspaceIngredient) || !value.formulas.every(validFormulaRecord) || !value.sessions.every(validMethodSession)) return false;
  const totalFormulaIngredients = value.formulas.reduce((total, formula) => total + formula.ingredients.length, 0);
  if (totalFormulaIngredients > 10_000) return false;
  try {
    const serialized = JSON.stringify(value);
    return typeof serialized === "string" && encodeUtf8(serialized).length <= 1_000_000;
  } catch { return false; }
}
