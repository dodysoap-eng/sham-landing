import type { WorkspaceData } from "./sham-domain";

export type RemoteWorkspace = { payload: unknown; revision: number; updatedAt?: string } | null;
export type SyncDecision = "upload-local" | "adopt-cloud" | "unchanged" | "conflict";

const hasData = (workspace: WorkspaceData | null) => Boolean(workspace && (workspace.ingredients.length || workspace.formulas.length || workspace.sessions.length));
const equalWorkspace = (left: WorkspaceData, right: WorkspaceData) => JSON.stringify(left) === JSON.stringify(right);

export function decideSyncAction(input: {
  local: WorkspaceData | null;
  remote: WorkspaceData | null;
  remoteRevision: number;
  baseRevision: number | null;
  pending: boolean;
  localIsLegacy?: boolean;
  remoteIsLegacy?: boolean;
}): SyncDecision {
  const { local, remote, remoteRevision, baseRevision, pending, localIsLegacy, remoteIsLegacy } = input;
  if (localIsLegacy || remoteIsLegacy) return "conflict";
  if (local && remote && hasData(local) !== hasData(remote)) {
    // Empty/non-empty snapshots conflict unless a pending local change targets the exact CAS revision.
    if (pending && baseRevision !== null && remoteRevision === baseRevision) return "upload-local";
    return "conflict";
  }
  if (!remote) {
    if (local && pending && baseRevision !== null && remoteRevision === baseRevision) return "upload-local";
    if (!local && !pending && baseRevision === null) return "unchanged";
    return "conflict";
  }
  if (!local) return "adopt-cloud";
  if (baseRevision === null) {
    if (!hasData(local) && !hasData(remote)) return "adopt-cloud";
    return equalWorkspace(local, remote) ? "adopt-cloud" : "conflict";
  }
  if (remoteRevision === baseRevision) {
    if (pending) return "upload-local";
    // The encrypted local snapshot is the durable source of truth if the app
    // stopped after writing it but before persisting the separate pending flag.
    return equalWorkspace(local, remote) ? "unchanged" : "upload-local";
  }
  if (pending && equalWorkspace(local, remote)) return "adopt-cloud";
  if (pending) return "conflict";
  return "adopt-cloud";
}

export function shouldKeepPendingAfterDisable(pending: boolean): boolean {
  return pending;
}
