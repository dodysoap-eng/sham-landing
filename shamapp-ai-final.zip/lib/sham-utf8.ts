export function encodeUtf8(value: string): Uint8Array {
  const bytes: number[] = [];
  for (let index = 0; index < value.length; index += 1) {
    let point = value.codePointAt(index)!;
    if (point > 0xffff) index += 1;
    else if (point >= 0xd800 && point <= 0xdfff) point = 0xfffd;

    if (point <= 0x7f) bytes.push(point);
    else if (point <= 0x7ff) bytes.push(0xc0 | (point >> 6), 0x80 | (point & 0x3f));
    else if (point <= 0xffff) bytes.push(0xe0 | (point >> 12), 0x80 | ((point >> 6) & 0x3f), 0x80 | (point & 0x3f));
    else bytes.push(0xf0 | (point >> 18), 0x80 | ((point >> 12) & 0x3f), 0x80 | ((point >> 6) & 0x3f), 0x80 | (point & 0x3f));
  }
  return Uint8Array.from(bytes);
}

export function decodeUtf8(bytes: Uint8Array): string {
  const parts: string[] = [];
  for (let index = 0; index < bytes.length;) {
    const first = bytes[index]!;
    let point: number;
    let length: number;
    if (first <= 0x7f) { point = first; length = 1; }
    else if (first >= 0xc2 && first <= 0xdf) { point = first & 0x1f; length = 2; }
    else if (first >= 0xe0 && first <= 0xef) { point = first & 0x0f; length = 3; }
    else if (first >= 0xf0 && first <= 0xf4) { point = first & 0x07; length = 4; }
    else throw new Error("بيانات UTF-8 غير صالحة.");

    if (index + length > bytes.length) throw new Error("بيانات UTF-8 مبتورة.");
    for (let offset = 1; offset < length; offset += 1) {
      const next = bytes[index + offset]!;
      if (next < 0x80 || next > 0xbf) throw new Error("بيانات UTF-8 غير صالحة.");
      if (offset === 1 && ((first === 0xe0 && next < 0xa0) || (first === 0xed && next > 0x9f) || (first === 0xf0 && next < 0x90) || (first === 0xf4 && next > 0x8f))) {
        throw new Error("ترميز UTF-8 غير قانوني.");
      }
      point = (point << 6) | (next & 0x3f);
    }

    if (point <= 0xffff) parts.push(String.fromCharCode(point));
    else {
      const adjusted = point - 0x10000;
      parts.push(String.fromCharCode(0xd800 + (adjusted >> 10), 0xdc00 + (adjusted & 0x3ff)));
    }
    index += length;
  }
  return parts.join("");
}
