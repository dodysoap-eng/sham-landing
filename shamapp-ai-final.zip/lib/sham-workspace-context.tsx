import AsyncStorage from "@react-native-async-storage/async-storage";
import { AppState } from "react-native";
import * as Network from "expo-network";
import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import type { FormulaRecord, MethodSession, WorkspaceData, WorkspaceIngredient } from "@/lib/sham-domain";
import { createEmptyWorkspace } from "@/lib/sham-domain";
import { trpc } from "@/lib/trpc";
import { clearCloudKey, getCachedCloudKey, getOrCreateDeviceKey, storeCloudKey } from "@/lib/sham-key-storage";
import {
  decryptLocalValue,
  decryptWorkspace,
  createCloudSalt,
  deriveCloudKey,
  equalWorkspace,
  encryptLocalValue,
  encryptLocalWorkspace,
  encryptWorkspace,
  isEncryptedLocalWorkspace,
  isEncryptedWorkspace,
  validateWorkspacePayload,
  validateRecoveryPhrase,
} from "@/lib/sham-sync-crypto";
import { decideSyncAction } from "@/lib/sham-sync-state";

export type SyncStatus = "loading" | "saved" | "saving" | "offline" | "local" | "conflict" | "locked";
export type WorkspaceConflict = {
  local: WorkspaceData;
  cloud: WorkspaceData;
  cloudRevision: number;
  cloudIsLegacy: boolean;
  detectedAt: string;
};
type SyncMetadata = { baseRevision: number | null; pending: boolean; cloudSalt: string | null; lastSyncedAt: string | null; legacyChoiceRequired: boolean; legacyChoiceResolved: boolean };
type WorkspaceContextValue = {
  workspace: WorkspaceData;
  ready: boolean;
  syncStatus: SyncStatus;
  cloudConsent: boolean;
  syncConflict: WorkspaceConflict | null;
  conflictBackup: WorkspaceConflict | null;
  hasPendingChanges: boolean;
  retryPaused: boolean;
  enableCloudSync: (recoveryPhrase: string) => Promise<void>;
  disableCloudSync: () => Promise<void>;
  deleteCloudCopy: () => Promise<void>;
  resolveConflict: (choice: "local" | "cloud") => Promise<void>;
  clearConflictBackup: () => Promise<void>;
  retrySyncNow: () => Promise<void>;
  updateWorkspace: (updater: (current: WorkspaceData) => WorkspaceData) => Promise<void>;
  saveFormula: (formula: FormulaRecord) => Promise<void>;
  removeFormula: (formulaId: string) => Promise<void>;
  addIngredient: (ingredient: WorkspaceIngredient) => Promise<void>;
  removeIngredient: (ingredientId: string) => Promise<void>;
  saveSession: (session: MethodSession) => Promise<void>;
};

const WorkspaceContext = createContext<WorkspaceContextValue | null>(null);
const cacheKeyForUser = (openId: string) => `sham.workspace.encrypted.v2:${openId}`;
const legacyKeyForUser = (openId: string) => `sham.workspace.v1:${openId}`;
const consentKeyForUser = (openId: string) => `sham.cloud-consent.v1:${openId}`;
const metadataKeyForUser = (openId: string) => `sham.sync-metadata.v2:${openId}`;
const conflictKeyForUser = (openId: string) => `sham.sync-conflict.v1:${openId}`;
const conflictArchiveKeyForUser = (openId: string) => `sham.sync-conflict-archive.v1:${openId}`;
const emptyMetadata = (): SyncMetadata => ({ baseRevision: null, pending: false, cloudSalt: null, lastSyncedAt: null, legacyChoiceRequired: false, legacyChoiceResolved: false });
const hasWorkspaceData = (value: WorkspaceData | null) => Boolean(value && (value.ingredients.length || value.formulas.length || value.sessions.length));
const MAX_SYNC_RETRIES = 8;

async function waitForCloudIdle(
  syncing: { current: boolean },
  writes: { current: number },
  setup: { current: boolean },
  timeoutMs = 30_000,
): Promise<boolean> {
  const deadline = Date.now() + timeoutMs;
  const busy = () => syncing.current || writes.current > 0 || setup.current;
  while (busy() && Date.now() < deadline) await new Promise<void>((resolve) => setTimeout(resolve, 25));
  return !busy();
}

function parseMetadata(raw: string | null): SyncMetadata {
  if (!raw) return emptyMetadata();
  try {
    const item = JSON.parse(raw) as Partial<SyncMetadata>;
    return {
      baseRevision: Number.isInteger(item.baseRevision) && Number(item.baseRevision) >= 0 ? Number(item.baseRevision) : null,
      pending: item.pending === true,
      cloudSalt: typeof item.cloudSalt === "string" && /^[0-9a-f]{32}$/i.test(item.cloudSalt) ? item.cloudSalt : null,
      lastSyncedAt: typeof item.lastSyncedAt === "string" ? item.lastSyncedAt : null,
      legacyChoiceRequired: item.legacyChoiceRequired === true,
      legacyChoiceResolved: item.legacyChoiceResolved === true,
    };
  } catch { return emptyMetadata(); }
}

function decodeCloudPayload(payload: unknown, key: Uint8Array, openId: string): { workspace: WorkspaceData; legacy: boolean } {
  if (isEncryptedWorkspace(payload)) return { workspace: decryptWorkspace(payload, key, openId), legacy: false };
  if (validateWorkspacePayload(payload)) return { workspace: payload, legacy: true };
  throw new Error("صيغة النسخة السحابية غير معروفة؛ لم تتغير بيانات الجهاز أو السحابة.");
}

function validConflict(value: unknown): value is WorkspaceConflict {
  if (!value || typeof value !== "object") return false;
  const item = value as Partial<WorkspaceConflict>;
  return validateWorkspacePayload(item.local) && validateWorkspacePayload(item.cloud) && Number.isInteger(item.cloudRevision) && Number(item.cloudRevision) >= 0 && Number(item.cloudRevision) <= 2_147_483_646 && typeof item.cloudIsLegacy === "boolean" && typeof item.detectedAt === "string" && item.detectedAt.length <= 80;
}

export function ShamWorkspaceProvider({ openId, children }: { openId: string; children: ReactNode }) {
  const [workspace, setWorkspace] = useState<WorkspaceData>(createEmptyWorkspace());
  const workspaceRef = useRef(workspace);
  const [localReady, setLocalReady] = useState(false);
  const [ready, setReady] = useState(false);
  const [cloudConsent, setCloudConsent] = useState(false);
  const cloudConsentRef = useRef(false);
  const [syncStatus, setSyncStatus] = useState<SyncStatus>("loading");
  const [syncConflict, setSyncConflict] = useState<WorkspaceConflict | null>(null);
  const syncConflictRef = useRef<WorkspaceConflict | null>(null);
  const [conflictBackup, setConflictBackup] = useState<WorkspaceConflict | null>(null);
  const [hasPendingChanges, setHasPendingChanges] = useState(false);
  const [retryPaused, setRetryPaused] = useState(false);
  const localWorkspace = useRef<WorkspaceData | null>(null);
  const localLegacy = useRef(false);
  const localGeneration = useRef(0);
  const localWriteQueue = useRef<Promise<unknown>>(Promise.resolve());
  const deviceKey = useRef<Uint8Array | null>(null);
  const cloudKey = useRef<Uint8Array | null>(null);
  const cloudSalt = useRef<string | null>(null);
  const metadata = useRef<SyncMetadata>(emptyMetadata());
  const localVaultUnavailable = useRef(false);
  const providerActive = useRef(false);
  const activeUser = useRef(openId);
  activeUser.current = openId;
  const saveQueue = useRef<Promise<unknown>>(Promise.resolve());
  const syncInProgress = useRef(false);
  const cloudWriteCount = useRef(0);
  const syncSetupInProgress = useRef(false);
  const cloudConsentGeneration = useRef(0);
  const retryPausedRef = useRef(false);
  const syncRef = useRef<(() => Promise<void>) | null>(null);
  const requestRetry = useRef<(() => void) | null>(null);
  const retryCount = useRef(0);
  const isCurrentOwner = useCallback(() => providerActive.current && activeUser.current === openId, [openId]);
  const isCurrentGeneration = useCallback((generation: number) => isCurrentOwner() && cloudConsentGeneration.current === generation, [isCurrentOwner]);
  const utils = trpc.useUtils();
  const saveMutation = trpc.workspace.save.useMutation();
  const removeMutation = trpc.workspace.remove.useMutation();
  const saveAsync = saveMutation.mutateAsync;
  const removeCloudAsync = removeMutation.mutateAsync;

  const chooseWorkspace = useCallback((next: WorkspaceData | null) => {
    const selected = next ?? createEmptyWorkspace();
    localGeneration.current += 1;
    localWorkspace.current = next;
    workspaceRef.current = selected;
    setWorkspace(selected);
  }, []);

  const persistLocal = useCallback(async (value: WorkspaceData, userId = openId, generation = localGeneration.current, completeLegacyChoice = false): Promise<boolean> => {
    const operation = localWriteQueue.current.catch(() => undefined).then(async () => {
      const key = deviceKey.current;
      if (!key || !isCurrentOwner() || activeUser.current !== userId) throw new Error("تعذر فتح مخزن الجهاز الآمن.");
      if (generation !== localGeneration.current) return false;
      const envelope = await encryptLocalWorkspace(value, key, userId);
      if (generation !== localGeneration.current || !isCurrentOwner() || activeUser.current !== userId) return false;
      await AsyncStorage.setItem(cacheKeyForUser(userId), JSON.stringify(envelope));
      if (completeLegacyChoice && isCurrentOwner() && activeUser.current === userId) {
        const nextMetadata = { ...metadata.current, legacyChoiceRequired: false, legacyChoiceResolved: true };
        await AsyncStorage.setItem(metadataKeyForUser(userId), JSON.stringify(nextMetadata));
        if (generation !== localGeneration.current || !isCurrentOwner() || activeUser.current !== userId) return false;
        metadata.current = nextMetadata;
        localLegacy.current = false;
        setHasPendingChanges(nextMetadata.pending);
        try { await AsyncStorage.removeItem(legacyKeyForUser(userId)); } catch { /* The encrypted cache and resolved-choice marker remain authoritative. */ }
      } else if (!localLegacy.current && isCurrentOwner() && activeUser.current === userId) {
        try { await AsyncStorage.removeItem(legacyKeyForUser(userId)); } catch { /* Keep the encrypted cache authoritative if cleanup fails. */ }
      }
      return true;
    });
    localWriteQueue.current = operation;
    return operation;
  }, [isCurrentOwner, openId]);

  const persistMetadata = useCallback(async (next: SyncMetadata, userId = openId) => {
    if (!isCurrentOwner() || activeUser.current !== userId) return;
    metadata.current = next;
    setHasPendingChanges(next.pending);
    await AsyncStorage.setItem(metadataKeyForUser(userId), JSON.stringify(next));
  }, [isCurrentOwner, openId]);

  const persistConflict = useCallback(async (value: WorkspaceConflict, userId = openId) => {
    if (!isCurrentOwner() || activeUser.current !== userId) return;
    if (!validConflict(value)) throw new Error("لا يمكن حفظ تعارض يحتوي بيانات غير صالحة.");
    const key = deviceKey.current;
    if (!key) throw new Error("تعذر فتح مخزن الجهاز الآمن.");
    const conflict = { ...value, local: localWorkspace.current ?? value.local };
    syncConflictRef.current = conflict;
    try {
      const envelope = await encryptLocalValue(conflict, key, userId);
      if (!isCurrentOwner() || activeUser.current !== userId) return;
      await AsyncStorage.setItem(conflictKeyForUser(userId), JSON.stringify(envelope));
      if (isCurrentOwner()) {
        setSyncConflict(conflict);
        setSyncStatus("conflict");
      }
    } catch (error) {
      if (isCurrentOwner()) {
        setSyncConflict(conflict);
        setSyncStatus("conflict");
      }
      throw error;
    }
  }, [isCurrentOwner, openId]);

  const saveCloud = useCallback(async (value: WorkspaceData, expectedRevision: number): Promise<boolean> => {
    if (!isCurrentOwner() || !cloudConsentRef.current) return false;
    cloudWriteCount.current += 1;
    try {
      const consentGeneration = cloudConsentGeneration.current;
      const key = cloudKey.current;
      const salt = cloudSalt.current ?? metadata.current.cloudSalt;
      if (!key || !salt) throw new Error("المزامنة مقفلة. أدخل عبارة الاسترداد لفتحها.");
      const envelope = await encryptWorkspace(value, key, salt, openId);
      if (!isCurrentGeneration(consentGeneration) || !cloudConsentRef.current) return false;
      const result = await saveAsync({ payload: envelope, expectedRevision, expectedOpenId: openId });
      if (!isCurrentGeneration(consentGeneration) || !cloudConsentRef.current) return false;
      if (result.saved) {
        const now = new Date().toISOString();
        const localIsNewer = Boolean(localWorkspace.current && !equalWorkspace(localWorkspace.current, value));
        await persistMetadata({ ...metadata.current, baseRevision: result.revision, pending: localIsNewer, cloudSalt: salt, lastSyncedAt: now });
        if (!isCurrentGeneration(consentGeneration)) return false;
        setHasPendingChanges(localIsNewer);
        retryCount.current = 0;
        retryPausedRef.current = false;
        setRetryPaused(false);
        setSyncStatus(localIsNewer ? "saving" : "saved");
        if (localIsNewer) requestRetry.current?.();
        void utils.workspace.load.invalidate();
        return true;
      }

      const conflictPayload = result.conflict.payload;
      let cloudWorkspace = createEmptyWorkspace();
      let cloudIsLegacy = false;
      if (conflictPayload !== null) {
        const decoded = decodeCloudPayload(conflictPayload, key, openId);
        cloudWorkspace = decoded.workspace;
        cloudIsLegacy = decoded.legacy;
      }
      const conflict: WorkspaceConflict = {
        local: localWorkspace.current ?? value,
        cloud: cloudWorkspace,
        cloudRevision: result.conflict.revision,
        cloudIsLegacy,
        detectedAt: new Date().toISOString(),
      };
      await persistConflict(conflict);
      if (!isCurrentGeneration(consentGeneration)) return false;
      await persistMetadata({ ...metadata.current, pending: true, cloudSalt: salt });
      if (!isCurrentGeneration(consentGeneration)) return false;
      return false;
    } finally {
      cloudWriteCount.current = Math.max(0, cloudWriteCount.current - 1);
      if (!cloudConsentRef.current && isCurrentOwner()) setSyncStatus("local");
    }
  }, [isCurrentGeneration, isCurrentOwner, openId, persistMetadata, persistConflict, saveAsync, utils]);

  const syncNow = useCallback(async () => {
    if (!isCurrentOwner() || localVaultUnavailable.current) return;
    if (!cloudConsentRef.current || !deviceKey.current) return;
    if (syncSetupInProgress.current) return;
    if (!cloudKey.current) {
      setSyncStatus("locked");
      return;
    }
    if (syncInProgress.current || syncConflictRef.current) return;
    syncInProgress.current = true;
    const operationGeneration = cloudConsentGeneration.current;
    const generationAtStart = localGeneration.current;
    try {
      const remote = await utils.workspace.load.fetch({ expectedOpenId: openId }, { staleTime: 0 });
      if (!isCurrentGeneration(operationGeneration)) return;
      if (remote && remote.payload == null) throw new Error("صيغة النسخة السحابية فارغة وغير صالحة؛ لم نرفع أو نستبدل أي نسخة.");
      const key = cloudKey.current;
      if (!key) { setSyncStatus("locked"); return; }
      const decoded = remote?.payload == null ? null : decodeCloudPayload(remote.payload, key, openId);
      const local = localWorkspace.current;
      const decision = decideSyncAction({
        local,
        remote: decoded?.workspace ?? null,
        remoteRevision: remote?.revision ?? 0,
        baseRevision: metadata.current.baseRevision,
        pending: metadata.current.pending || localGeneration.current !== generationAtStart,
        localIsLegacy: localLegacy.current,
        remoteIsLegacy: decoded?.legacy ?? false,
      });

      if (decision === "conflict") {
        await persistConflict({ local: local ?? createEmptyWorkspace(), cloud: decoded?.workspace ?? createEmptyWorkspace(), cloudRevision: remote?.revision ?? 0, cloudIsLegacy: decoded?.legacy ?? false, detectedAt: new Date().toISOString() });
        return;
      }
      if (decision === "adopt-cloud" && decoded && remote) {
        chooseWorkspace(decoded.workspace);
        const adoptedGeneration = localGeneration.current;
        const stored = await persistLocal(decoded.workspace, openId, adoptedGeneration);
        if (!isCurrentGeneration(operationGeneration)) return;
        if (!stored || localGeneration.current !== adoptedGeneration) {
          await persistMetadata({ ...metadata.current, baseRevision: remote.revision, pending: true });
          if (!isCurrentGeneration(operationGeneration)) return;
          requestRetry.current?.();
          return;
        }
        await persistMetadata({ ...metadata.current, baseRevision: remote.revision, pending: false, lastSyncedAt: new Date().toISOString() });
        if (!isCurrentGeneration(operationGeneration)) return;
        retryCount.current = 0;
        retryPausedRef.current = false;
        setRetryPaused(false);
        setSyncStatus("saved");
        return;
      }
      if (decision === "upload-local") {
        const value = localWorkspace.current ?? createEmptyWorkspace();
        await persistMetadata({ ...metadata.current, pending: true });
        if (!isCurrentGeneration(operationGeneration)) return;
        await saveCloud(value, remote?.revision ?? 0);
        return;
      }
      await persistMetadata({ ...metadata.current, baseRevision: remote?.revision ?? metadata.current.baseRevision, pending: false, lastSyncedAt: remote ? new Date().toISOString() : metadata.current.lastSyncedAt });
      if (!isCurrentGeneration(operationGeneration)) return;
      retryCount.current = 0;
      retryPausedRef.current = false;
      setRetryPaused(false);
      setSyncStatus("saved");
    } catch (error) {
      if (!isCurrentGeneration(operationGeneration)) return;
      if (!cloudConsentRef.current) { setSyncStatus("local"); throw error; }
      if (error instanceof Error && /authentication tag|invalid tag|decrypt|صيغة النسخة/i.test(error.message)) {
        cloudKey.current = null;
        setSyncStatus("locked");
      } else {
        setSyncStatus("offline");
        requestRetry.current?.();
      }
      throw error;
    } finally {
      syncInProgress.current = false;
      if (!cloudConsentRef.current && isCurrentOwner()) setSyncStatus("local");
    }
  }, [chooseWorkspace, isCurrentGeneration, isCurrentOwner, openId, persistLocal, persistMetadata, persistConflict, saveCloud, syncConflict, utils]);
  syncRef.current = syncNow;

  const enableCloudSync = useCallback(async (recoveryPhrase: string) => {
    const invalid = validateRecoveryPhrase(recoveryPhrase);
    if (invalid) throw new Error(invalid);
    if (!ready && !localVaultUnavailable.current) throw new Error("مساحة العمل لا تزال تُحمّل.");
    if (syncSetupInProgress.current) throw new Error("إعداد المزامنة جارٍ بالفعل.");
    if (!isCurrentOwner()) throw new Error("تغير الحساب؛ أعد فتح مساحة العمل قبل تفعيل المزامنة.");
    const operationGeneration = ++cloudConsentGeneration.current;
    const wasAlreadyEnabled = cloudConsentRef.current;
    syncSetupInProgress.current = true;
    retryCount.current = 0;
    retryPausedRef.current = false;
    setRetryPaused(false);
    try {
    if (!deviceKey.current) {
      deviceKey.current = await getOrCreateDeviceKey(openId);
      if (!isCurrentGeneration(operationGeneration)) return;
    }
    setSyncStatus("loading");
    let remote: Awaited<ReturnType<typeof utils.workspace.load.fetch>> | null = null;
    let remoteLoadSucceeded = true;
    try { remote = await utils.workspace.load.fetch({ expectedOpenId: openId }, { staleTime: 0 }); }
    catch { remoteLoadSucceeded = false; }
    if (!isCurrentGeneration(operationGeneration)) return;
    if (!remoteLoadSucceeded) {
      setSyncStatus("offline");
      throw new Error("تعذر قراءة النسخة السحابية؛ لم أرفع أو أستبدل أي نسخة. أعد المحاولة عند توفر الاتصال.");
    }
    if (remote && remote.payload == null) {
      setSyncStatus("locked");
      throw new Error("صيغة النسخة السحابية فارغة وغير صالحة؛ لم نرفع أو نستبدل أي نسخة.");
    }

    const remoteEnvelope = remote?.payload && isEncryptedWorkspace(remote.payload) ? remote.payload : null;
    const salt = remoteEnvelope?.salt ?? metadata.current.cloudSalt ?? await createCloudSalt();
    if (!isCurrentGeneration(operationGeneration)) return;
    const derived = await deriveCloudKey(recoveryPhrase, salt);
    if (!isCurrentGeneration(operationGeneration)) return;
    let remoteData: WorkspaceData | null = null;
    let remoteLegacy = false;
    if (remote?.payload != null) {
      try {
        const decoded = decodeCloudPayload(remote.payload, derived, openId);
        remoteData = decoded.workspace;
        remoteLegacy = decoded.legacy;
      } catch (error) {
        setSyncStatus("locked");
        if (remoteEnvelope) throw new Error("عبارة الاسترداد غير صحيحة؛ لم تتغير أي نسخة.");
        throw error;
      }
    }

    if (localVaultUnavailable.current && !remoteData) {
      setSyncStatus("locked");
      throw new Error("تعذر فتح النسخة المحلية ولا توجد نسخة سحابية قابلة للاسترداد؛ لم أستبدل بيانات الجهاز.");
    }
    if (localVaultUnavailable.current && remoteData) {
      const unopenedLocal = await AsyncStorage.getItem(cacheKeyForUser(openId));
      if (!isCurrentGeneration(operationGeneration)) return;
      if (unopenedLocal) await AsyncStorage.setItem(`sham.recovery-cache.v1:${openId}`, unopenedLocal);
      if (!isCurrentGeneration(operationGeneration)) return;
      localVaultUnavailable.current = false;
    }

    await storeCloudKey(openId, derived);
    if (!isCurrentGeneration(operationGeneration)) return;
    cloudKey.current = derived;
    cloudSalt.current = salt;
    if (!wasAlreadyEnabled) {
      await AsyncStorage.setItem(consentKeyForUser(openId), "true");
      if (!isCurrentGeneration(operationGeneration)) {
        if (isCurrentOwner() && !cloudConsentRef.current) await AsyncStorage.setItem(consentKeyForUser(openId), "false");
        return;
      }
      cloudConsentRef.current = true;
      setCloudConsent(true);
    }
    const local = localWorkspace.current;

    if (remote && remoteData && remoteLegacy) {
      await persistMetadata({ ...metadata.current, baseRevision: metadata.current.baseRevision ?? remote.revision, pending: true, cloudSalt: salt });
      if (!isCurrentGeneration(operationGeneration)) return;
      await persistConflict({
        local: local ?? createEmptyWorkspace(),
        cloud: remoteData,
        cloudRevision: remote.revision,
        cloudIsLegacy: true,
        detectedAt: new Date().toISOString(),
      });
      if (!isCurrentGeneration(operationGeneration)) return;
      setReady(true);
      return;
    }

    if (localLegacy.current) {
      await persistMetadata({ ...metadata.current, baseRevision: remote?.revision ?? 0, pending: true, cloudSalt: salt });
      if (!isCurrentGeneration(operationGeneration)) return;
      await persistConflict({
        local: local ?? createEmptyWorkspace(),
        cloud: remoteData ?? createEmptyWorkspace(),
        cloudRevision: remote?.revision ?? 0,
        cloudIsLegacy: false,
        detectedAt: new Date().toISOString(),
      });
      if (!isCurrentGeneration(operationGeneration)) return;
      setReady(true);
      return;
    }

    if (remote && remoteData && local && !hasWorkspaceData(local) && hasWorkspaceData(remoteData)) {
      await persistMetadata({ ...metadata.current, baseRevision: metadata.current.baseRevision ?? remote.revision, pending: true, cloudSalt: salt });
      if (!isCurrentGeneration(operationGeneration)) return;
      await persistConflict({ local, cloud: remoteData, cloudRevision: remote.revision, cloudIsLegacy: remoteLegacy, detectedAt: new Date().toISOString() });
      if (!isCurrentGeneration(operationGeneration)) return;
      setReady(true);
      return;
    }

    if (remote && remoteData && local && hasWorkspaceData(remoteData) && hasWorkspaceData(local) && !equalWorkspace(remoteData, local)) {
      const conflict: WorkspaceConflict = { local, cloud: remoteData, cloudRevision: remote.revision, cloudIsLegacy: remoteLegacy, detectedAt: new Date().toISOString() };
      await persistMetadata({ ...metadata.current, baseRevision: metadata.current.baseRevision ?? remote.revision, pending: true, cloudSalt: salt });
      if (!isCurrentGeneration(operationGeneration)) return;
      await persistConflict(conflict);
      if (!isCurrentGeneration(operationGeneration)) return;
      setReady(true);
      return;
    }

    if (remote && remoteData && local && hasWorkspaceData(local) && !hasWorkspaceData(remoteData)) {
      const baseRevision = metadata.current.baseRevision;
      const pendingAgainstCurrentRevision = metadata.current.pending && baseRevision !== null && remote.revision === baseRevision;
      if (!pendingAgainstCurrentRevision) {
        await persistMetadata({ ...metadata.current, baseRevision: baseRevision ?? remote.revision, pending: true, cloudSalt: salt });
        if (!isCurrentGeneration(operationGeneration)) return;
        await persistConflict({ local, cloud: remoteData, cloudRevision: remote.revision, cloudIsLegacy: false, detectedAt: new Date().toISOString() });
        if (!isCurrentGeneration(operationGeneration)) return;
        setReady(true);
        return;
      }
      chooseWorkspace(local);
      const localGenerationAtSave = localGeneration.current;
      const stored = await persistLocal(local, openId, localGenerationAtSave);
      if (!isCurrentGeneration(operationGeneration)) return;
      if (!stored || localGeneration.current !== localGenerationAtSave) {
        await persistMetadata({ ...metadata.current, baseRevision: remote.revision, pending: true, cloudSalt: salt });
        if (!isCurrentGeneration(operationGeneration)) return;
        setReady(true);
        requestRetry.current?.();
        return;
      }
      await persistMetadata({ ...metadata.current, baseRevision: remote.revision, pending: true, cloudSalt: salt });
      if (!isCurrentGeneration(operationGeneration)) return;
      try { await saveCloud(local, remote.revision); }
      catch { setSyncStatus("offline"); requestRetry.current?.(); }
      if (!isCurrentGeneration(operationGeneration)) return;
      setReady(true);
      return;
    }

    if (remote && remoteData && (!local || !hasWorkspaceData(local))) {
      chooseWorkspace(remoteData);
      const adoptedGeneration = localGeneration.current;
      const stored = await persistLocal(remoteData, openId, adoptedGeneration);
      if (!isCurrentGeneration(operationGeneration)) return;
      if (!stored || localGeneration.current !== adoptedGeneration) {
        await persistMetadata({ ...metadata.current, baseRevision: remote.revision, pending: true, cloudSalt: salt });
        setReady(true);
        requestRetry.current?.();
        return;
      }
      await persistMetadata({ ...metadata.current, baseRevision: remote.revision, pending: false, cloudSalt: salt });
      setSyncStatus("saved");
      setReady(true);
      return;
    }
    if (remote && remoteData && local && equalWorkspace(remoteData, local)) {
      chooseWorkspace(remoteData);
      const adoptedGeneration = localGeneration.current;
      const stored = await persistLocal(remoteData, openId, adoptedGeneration);
      if (!isCurrentGeneration(operationGeneration)) return;
      if (!stored || localGeneration.current !== adoptedGeneration) {
        await persistMetadata({ ...metadata.current, baseRevision: remote.revision, pending: true, cloudSalt: salt });
        setReady(true);
        requestRetry.current?.();
        return;
      }
      await persistMetadata({ ...metadata.current, baseRevision: remote.revision, pending: false, cloudSalt: salt });
      setSyncStatus("saved");
      setReady(true);
      return;
    }

    if (!remote && (local !== null || metadata.current.pending || metadata.current.baseRevision !== null) && !(local && metadata.current.pending && metadata.current.baseRevision === 0)) {
      await persistMetadata({ ...metadata.current, pending: true, cloudSalt: salt });
      if (!isCurrentGeneration(operationGeneration)) return;
      await persistConflict({ local: local ?? createEmptyWorkspace(), cloud: createEmptyWorkspace(), cloudRevision: 0, cloudIsLegacy: false, detectedAt: new Date().toISOString() });
      if (!isCurrentGeneration(operationGeneration)) return;
      setReady(true);
      return;
    }

    const selected = local ?? remoteData ?? createEmptyWorkspace();
    chooseWorkspace(selected);
    const selectedGeneration = localGeneration.current;
    const stored = await persistLocal(selected, openId, selectedGeneration);
    if (!isCurrentGeneration(operationGeneration)) return;
    const newerLocal = !stored || localGeneration.current !== selectedGeneration;
    const pending = Boolean(newerLocal || !remoteData && hasWorkspaceData(selected) || wasAlreadyEnabled && metadata.current.pending);
    await persistMetadata({ ...metadata.current, baseRevision: remote?.revision ?? 0, pending, cloudSalt: salt });
    setReady(true);
    if (newerLocal) { requestRetry.current?.(); return; }
    if (pending) {
      try { await saveCloud(selected, remote?.revision ?? 0); }
      catch { setSyncStatus("offline"); requestRetry.current?.(); }
    } else {
      setSyncStatus("saved");
    }
    } finally {
      syncSetupInProgress.current = false;
      if (!cloudConsentRef.current && isCurrentOwner()) setSyncStatus((current) => current === "loading" ? "local" : current);
    }
  }, [chooseWorkspace, isCurrentGeneration, isCurrentOwner, openId, persistLocal, persistMetadata, persistConflict, ready, saveCloud, utils]);

  const disableCloudSync = useCallback(async () => {
    cloudConsentGeneration.current += 1;
    cloudConsentRef.current = false;
    if (isCurrentOwner()) setCloudConsent(false);
    await AsyncStorage.setItem(consentKeyForUser(openId), "false");
    const idle = await waitForCloudIdle(syncInProgress, cloudWriteCount, syncSetupInProgress);
    if (!idle) {
      if (isCurrentOwner()) setSyncStatus("saving");
      throw new Error("أُوقفت الطلبات الجديدة، لكن الحفظ الذي بدأ قبل الإيقاف لم ينتهِ بعد؛ لم نعلن اكتمال الإيقاف.");
    }
    await saveQueue.current;
    if (!isCurrentOwner()) return;
    setSyncStatus("local");
    setReady(true);
  }, [isCurrentOwner, openId]);

  const deleteCloudCopy = useCallback(async () => {
    const operationGeneration = ++cloudConsentGeneration.current;
    cloudConsentRef.current = false;
    if (isCurrentOwner()) setCloudConsent(false);
    await AsyncStorage.setItem(consentKeyForUser(openId), "false");
    if (!isCurrentGeneration(operationGeneration)) return;
    const idle = await waitForCloudIdle(syncInProgress, cloudWriteCount, syncSetupInProgress);
    if (!idle) {
      if (isCurrentOwner()) setSyncStatus("saving");
      throw new Error("أُوقفت الطلبات الجديدة، لكن الحفظ الذي بدأ قبل الإيقاف لم ينتهِ؛ لم تُحذف النسخة السحابية.");
    }
    await saveQueue.current;
    if (!isCurrentGeneration(operationGeneration)) return;

    const conflict = syncConflictRef.current;
    if (conflict && deviceKey.current) {
      const archive = await encryptLocalValue(conflict, deviceKey.current, openId);
      if (!isCurrentGeneration(operationGeneration)) return;
      await AsyncStorage.setItem(conflictArchiveKeyForUser(openId), JSON.stringify(archive));
      if (isCurrentOwner()) setConflictBackup(conflict);
    }
    if (!isCurrentGeneration(operationGeneration)) return;
    cloudWriteCount.current += 1;
    try { await removeCloudAsync({ expectedOpenId: openId }); }
    finally { cloudWriteCount.current = Math.max(0, cloudWriteCount.current - 1); }
    if (!isCurrentGeneration(operationGeneration)) return;
    cloudKey.current = null;
    cloudSalt.current = null;
    await clearCloudKey(openId);
    const clearedMetadata = {
      ...emptyMetadata(),
      legacyChoiceRequired: localLegacy.current,
      legacyChoiceResolved: !localLegacy.current && metadata.current.legacyChoiceResolved,
    };
    await AsyncStorage.multiSet([
      [consentKeyForUser(openId), "false"],
      [metadataKeyForUser(openId), JSON.stringify(clearedMetadata)],
    ]);
    metadata.current = clearedMetadata;
    if (isCurrentOwner()) {
      setCloudConsent(false);
      setHasPendingChanges(false);
    }
    if (conflict) {
      await AsyncStorage.removeItem(conflictKeyForUser(openId));
      syncConflictRef.current = null;
      if (isCurrentOwner()) setSyncConflict(null);
    }
    if (isCurrentOwner()) setSyncStatus("local");
  }, [isCurrentGeneration, isCurrentOwner, openId, removeCloudAsync]);

  const resolveConflict = useCallback(async (choice: "local" | "cloud") => {
    if (!isCurrentOwner()) throw new Error("تغير الحساب؛ أعد فتح مساحة العمل قبل حل التعارض.");
    const operationGeneration = cloudConsentGeneration.current;
    const conflict = syncConflict;
    if (!conflict) return;
    if ((choice === "local" || conflict.cloudIsLegacy) && !cloudConsentRef.current) {
      throw new Error("أعد تفعيل المزامنة المشفّرة قبل رفع نسخة أو ترحيل نسخة سحابية قديمة.");
    }
    if (choice === "cloud" && !conflict.cloudIsLegacy) {
      const latest = await utils.workspace.load.fetch({ expectedOpenId: openId }, { staleTime: 0 });
      if (!isCurrentGeneration(operationGeneration)) return;
      const latestRevision = latest?.revision ?? 0;
      if (latestRevision !== conflict.cloudRevision) {
        const key = cloudKey.current;
        if (latest?.payload != null && !key) throw new Error("أدخل عبارة الاسترداد لمراجعة أحدث نسخة سحابية.");
        const decoded = latest?.payload == null ? null : decodeCloudPayload(latest.payload, key!, openId);
        await persistConflict({
          local: localWorkspace.current ?? conflict.local,
          cloud: decoded?.workspace ?? createEmptyWorkspace(),
          cloudRevision: latestRevision,
          cloudIsLegacy: decoded?.legacy ?? false,
          detectedAt: new Date().toISOString(),
        });
        if (!isCurrentGeneration(operationGeneration)) return;
        throw new Error("تغيرت النسخة السحابية منذ عرض التعارض؛ لم نعتمد النسخة القديمة. راجع المراجعة الأحدث.");
      }
    }
    const selected = choice === "local" ? conflict.local : conflict.cloud;
    const backupEnvelope = await encryptLocalValue(conflict, deviceKey.current!, openId);
    if (!isCurrentGeneration(operationGeneration)) return;
    await AsyncStorage.setItem(conflictArchiveKeyForUser(openId), JSON.stringify(backupEnvelope));
    if (!isCurrentGeneration(operationGeneration)) return;
    setConflictBackup(conflict);
    chooseWorkspace(selected);
    await persistLocal(selected, openId, localGeneration.current, true);
    if (!isCurrentGeneration(operationGeneration)) return;
    if (choice === "local" || conflict.cloudIsLegacy) {
      await persistMetadata({ ...metadata.current, baseRevision: conflict.cloudRevision, pending: true });
      if (!isCurrentGeneration(operationGeneration)) return;
      const saved = await saveCloud(selected, conflict.cloudRevision);
      if (!saved) return;
    } else {
      await persistMetadata({ ...metadata.current, baseRevision: conflict.cloudRevision, pending: false, lastSyncedAt: new Date().toISOString() });
      if (!isCurrentGeneration(operationGeneration)) return;
    }
    await AsyncStorage.removeItem(conflictKeyForUser(openId));
    if (!isCurrentGeneration(operationGeneration)) return;
    syncConflictRef.current = null;
    setSyncConflict(null);
    setSyncStatus(cloudConsentRef.current ? "saved" : "local");
  }, [chooseWorkspace, isCurrentGeneration, isCurrentOwner, openId, persistConflict, persistLocal, persistMetadata, saveCloud, syncConflict, utils]);

  const clearConflictBackup = useCallback(async () => {
    await AsyncStorage.removeItem(conflictArchiveKeyForUser(openId));
    setConflictBackup(null);
  }, [openId]);

  const updateWorkspace = useCallback(async (updater: (current: WorkspaceData) => WorkspaceData) => {
    if (!isCurrentOwner()) throw new Error("تغير الحساب؛ أعد فتح مساحة العمل قبل التعديل.");
    if (!ready || localVaultUnavailable.current) throw new Error("افتح مخزن البيانات الآمن قبل التعديل.");
    if (syncConflictRef.current) throw new Error("حل تعارض نسخ السحابة والجهاز قبل متابعة التعديل.");
    if (activeUser.current !== openId) throw new Error("تغير الحساب؛ أعد فتح مساحة العمل قبل التعديل.");
    const next = { ...updater(workspaceRef.current), schemaVersion: 1 as const, updatedAt: new Date().toISOString() };
    if (!validateWorkspacePayload(next)) throw new Error("بيانات مساحة العمل غير صالحة أو تتجاوز حد التخزين.");
    const generation = ++localGeneration.current;
    retryCount.current = 0;
    retryPausedRef.current = false;
    setRetryPaused(false);
    workspaceRef.current = next;
    localWorkspace.current = next;
    setWorkspace(next);
    setSyncStatus(cloudConsentRef.current ? "saving" : "local");
    saveQueue.current = saveQueue.current.catch(() => undefined).then(async () => {
      const stored = await persistLocal(next, openId, generation);
      if (!stored) return;
      await persistMetadata({ ...metadata.current, pending: true });
      if (!cloudConsentRef.current) { setSyncStatus("local"); return; }
      if (!cloudKey.current) { setSyncStatus("locked"); return; }
      try { await syncRef.current?.(); }
      catch { setSyncStatus(cloudConsentRef.current ? "offline" : "local"); requestRetry.current?.(); }
    });
    await saveQueue.current;
  }, [isCurrentOwner, openId, persistLocal, persistMetadata, ready]);

  const saveFormula = useCallback(async (formula: FormulaRecord) => {
    await updateWorkspace((current) => ({ ...current, formulas: [formula, ...current.formulas.filter((item) => item.id !== formula.id)] }));
  }, [updateWorkspace]);
  const removeFormula = useCallback(async (formulaId: string) => {
    await updateWorkspace((current) => ({ ...current, formulas: current.formulas.filter((item) => item.id !== formulaId) }));
  }, [updateWorkspace]);
  const addIngredient = useCallback(async (ingredient: WorkspaceIngredient) => {
    await updateWorkspace((current) => ({ ...current, ingredients: [ingredient, ...current.ingredients.filter((item) => item.id !== ingredient.id)] }));
  }, [updateWorkspace]);
  const removeIngredient = useCallback(async (ingredientId: string) => {
    await updateWorkspace((current) => ({ ...current, ingredients: current.ingredients.filter((item) => item.id !== ingredientId) }));
  }, [updateWorkspace]);
  const saveSession = useCallback(async (session: MethodSession) => {
    await updateWorkspace((current) => ({ ...current, sessions: [session, ...current.sessions.filter((item) => item.id !== session.id)] }));
  }, [updateWorkspace]);

  useEffect(() => {
    let active = true;
    providerActive.current = true;
    localVaultUnavailable.current = false;
    setReady(false);
    setLocalReady(false);
    setSyncStatus("loading");
    setSyncConflict(null);
    syncConflictRef.current = null;
    setConflictBackup(null);
    setHasPendingChanges(false);
    localGeneration.current = 0;
    localWriteQueue.current = Promise.resolve();
    retryCount.current = 0;
    retryPausedRef.current = false;
    setRetryPaused(false);
    cloudConsentGeneration.current += 1;
    setCloudConsent(false);
    cloudConsentRef.current = false;
    cloudKey.current = null;
    cloudSalt.current = null;
    deviceKey.current = null;
    localWorkspace.current = null;
    localLegacy.current = false;
    workspaceRef.current = createEmptyWorkspace();
    setWorkspace(workspaceRef.current);
    metadata.current = emptyMetadata();
    saveQueue.current = Promise.resolve();
    syncInProgress.current = false;

    void (async () => {
      try {
        const key = await getOrCreateDeviceKey(openId);
        if (!active) return;
        deviceKey.current = key;
        const [cacheRaw, legacyRaw, consentRaw, metadataRaw, conflictRaw, archiveRaw, cachedCloudKey] = await Promise.all([
          AsyncStorage.getItem(cacheKeyForUser(openId)),
          AsyncStorage.getItem(legacyKeyForUser(openId)),
          AsyncStorage.getItem(consentKeyForUser(openId)),
          AsyncStorage.getItem(metadataKeyForUser(openId)),
          AsyncStorage.getItem(conflictKeyForUser(openId)),
          AsyncStorage.getItem(conflictArchiveKeyForUser(openId)),
          getCachedCloudKey(openId),
        ]);
        if (!active) return;
        const nextMetadata = parseMetadata(metadataRaw);
        let legacyCandidate: WorkspaceData | null = null;
        if (legacyRaw) {
          try {
            if (legacyRaw.length > 1_000_000) throw new Error("النسخة المحلية القديمة أكبر من الحد المسموح.");
            const old: unknown = JSON.parse(legacyRaw);
            if (validateWorkspacePayload(old)) legacyCandidate = old;
            else if (!cacheRaw) throw new Error("النسخة المحلية القديمة غير صالحة؛ احتفظنا بها دون مزامنة.");
          } catch (error) {
            if (!cacheRaw) throw error;
            /* Ignore an invalid legacy snapshot when a valid encrypted cache exists. */
          }
        }
        let local: WorkspaceData | null = null;
        if (cacheRaw) {
          if (cacheRaw.length > 3_100_000) throw new Error("المخزن المحلي أكبر من الحد الآمن.");
          const cached: unknown = JSON.parse(cacheRaw);
          if (!isEncryptedLocalWorkspace(cached)) throw new Error("صيغة المخزن المحلي غير معروفة.");
          local = decryptLocalValue<WorkspaceData>(cached, key, openId);
          if (!validateWorkspacePayload(local)) throw new Error("بيانات المخزن المحلي غير صالحة أو تتجاوز حد التخزين.");
        } else if (legacyCandidate) {
          local = legacyCandidate;
        }
        localLegacy.current = nextMetadata.legacyChoiceRequired || Boolean(legacyCandidate && (!cacheRaw || !nextMetadata.legacyChoiceResolved));
        const loadedMetadata = localLegacy.current
          ? { ...nextMetadata, legacyChoiceRequired: true, legacyChoiceResolved: false }
          : nextMetadata;
        if (loadedMetadata !== nextMetadata) {
          try { await AsyncStorage.setItem(metadataKeyForUser(openId), JSON.stringify(loadedMetadata)); }
          catch { /* The raw v1 snapshot remains available to rediscover this choice next launch. */ }
        }
        if (!active) return;
        localWorkspace.current = local;
        workspaceRef.current = local ?? createEmptyWorkspace();
        setWorkspace(workspaceRef.current);
        metadata.current = loadedMetadata;
        cloudSalt.current = loadedMetadata.cloudSalt;
        setHasPendingChanges(loadedMetadata.pending);
        cloudKey.current = cachedCloudKey;
        const enabled = consentRaw === "true";
        cloudConsentRef.current = enabled;
        setCloudConsent(enabled);
        let restoredConflict: WorkspaceConflict | null = null;
        if (conflictRaw) {
          if (conflictRaw.length > 6_100_000) throw new Error("نسخة التعارض المحلية أكبر من الحد الآمن.");
          const envelope: unknown = JSON.parse(conflictRaw);
          if (!isEncryptedLocalWorkspace(envelope)) throw new Error("صيغة نسخة التعارض المحلية غير معروفة.");
          const parsed = decryptLocalValue<unknown>(envelope, key, openId);
          if (!validConflict(parsed)) throw new Error("بيانات نسخة التعارض المحلية غير صالحة؛ أوقفنا المزامنة.");
          restoredConflict = parsed;
          syncConflictRef.current = parsed;
          setSyncConflict(parsed);
        }
        if (archiveRaw) {
          if (archiveRaw.length > 6_100_000) throw new Error("الأرشيف المحلي للتعارض أكبر من الحد الآمن.");
          const envelope: unknown = JSON.parse(archiveRaw);
          if (isEncryptedLocalWorkspace(envelope)) {
            const parsed = decryptLocalValue<unknown>(envelope, key, openId);
            if (validConflict(parsed)) setConflictBackup(parsed);
          }
        }
        setLocalReady(true);
        setReady(true);
        if (restoredConflict) setSyncStatus("conflict");
        else if (enabled && !cachedCloudKey) setSyncStatus("locked");
        else setSyncStatus(enabled ? "saving" : "local");
        if (enabled && cachedCloudKey && !conflictRaw) setTimeout(() => { if (active) void syncRef.current?.().catch(() => undefined); }, 0);
      } catch {
        if (!active) return;
        localVaultUnavailable.current = true;
        setLocalReady(true);
        setReady(true);
        setSyncStatus("locked");
      }
    })();
    return () => {
      active = false;
      providerActive.current = false;
      cloudConsentGeneration.current += 1;
      cloudConsentRef.current = false;
    };
  }, [openId]);

  useEffect(() => {
    if (!localReady || !cloudConsent || !cloudKey.current || syncConflict || syncSetupInProgress.current || localVaultUnavailable.current) return;
    void syncRef.current?.().catch(() => undefined);
  }, [localReady, cloudConsent, syncConflict]);

  useEffect(() => {
    let timer: ReturnType<typeof setTimeout> | null = null;
    let disposed = false;
    const clearTimer = () => { if (timer) clearTimeout(timer); timer = null; };
    const schedule = (immediate = false) => {
      if (retryPausedRef.current || retryCount.current >= MAX_SYNC_RETRIES) return;
      clearTimer();
      timer = setTimeout(async () => {
        timer = null;
        if (disposed || retryPausedRef.current || localVaultUnavailable.current || !cloudConsentRef.current || !metadata.current.pending || !cloudKey.current || syncConflictRef.current) return;
        try {
          const state = await Network.getNetworkStateAsync();
          if (state.isConnected === false || state.isInternetReachable === false) return;
          await syncRef.current?.();
          retryCount.current = 0;
          retryPausedRef.current = false;
          setRetryPaused(false);
        } catch {
          if (!cloudConsentRef.current) { setSyncStatus("local"); return; }
          retryCount.current += 1;
          if (retryCount.current >= MAX_SYNC_RETRIES) {
            clearTimer();
            retryPausedRef.current = true;
            setRetryPaused(true);
            setSyncStatus("offline");
          } else schedule();
        }
      }, immediate ? 150 : Math.min(1_000 * 2 ** retryCount.current, 60_000));
    };
    requestRetry.current = () => { if (cloudConsentRef.current && !retryPausedRef.current && !localVaultUnavailable.current) schedule(); };
    const networkSub = Network.addNetworkStateListener((state) => {
      if (state.isConnected && state.isInternetReachable !== false) {
        retryCount.current = 0;
        retryPausedRef.current = false;
        setRetryPaused(false);
        schedule(true);
      }
    });
    const appSub = AppState.addEventListener("change", (state) => { if (state === "active") schedule(true); });
    if (cloudConsentRef.current && metadata.current.pending) schedule(true);
    return () => {
      disposed = true;
      clearTimer();
      networkSub.remove();
      appSub.remove();
      requestRetry.current = null;
    };
  }, [openId, syncConflict]);

  const retrySyncNow = useCallback(async () => {
    if (!cloudConsentRef.current || syncConflictRef.current || localVaultUnavailable.current) return;
    retryCount.current = 0;
    retryPausedRef.current = false;
    setRetryPaused(false);
    await syncRef.current?.();
  }, []);

  const value = useMemo(() => ({
    workspace, ready, syncStatus, cloudConsent, syncConflict, conflictBackup, hasPendingChanges, retryPaused,
    enableCloudSync, disableCloudSync, deleteCloudCopy, resolveConflict, clearConflictBackup,
    retrySyncNow,
    updateWorkspace, saveFormula, removeFormula, addIngredient, removeIngredient, saveSession,
  }), [workspace, ready, syncStatus, cloudConsent, syncConflict, conflictBackup, hasPendingChanges, retryPaused, enableCloudSync, disableCloudSync, deleteCloudCopy, resolveConflict, clearConflictBackup, retrySyncNow, updateWorkspace, saveFormula, removeFormula, addIngredient, removeIngredient, saveSession]);
  return <WorkspaceContext.Provider value={value}>{children}</WorkspaceContext.Provider>;
}

export function useShamWorkspace() {
  const value = useContext(WorkspaceContext);
  if (!value) throw new Error("useShamWorkspace must be used inside ShamWorkspaceProvider");
  return value;
}
