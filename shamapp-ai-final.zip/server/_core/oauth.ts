import { randomBytes } from "node:crypto";
import { ONE_YEAR_MS } from "../../shared/const.js";
import { HttpError } from "../../shared/_core/errors.js";
import type { Express, Request, Response } from "express";
import { getUserByOpenId, upsertUser } from "../db";
import {
  getCookieValue,
  getOAuthStateCookieName,
  getSessionCookieName,
  getSessionCookieOptions,
} from "./cookies";
import { sdk } from "./sdk";

type OAuthClient = "web" | "native";
type OAuthState = { client: OAuthClient; nonce: string; redirectUri: string; expiresAt: number };
const OAUTH_STATE_TTL_MS = 5 * 60 * 1000;
const MAX_PENDING_STATES = 10_000;
const pendingStates = new Map<string, OAuthState>();
const NATIVE_OAUTH_SCHEME = "manus243795804825483";

function getQueryParam(req: Request, key: string): string | undefined {
  const value = req.query[key];
  return typeof value === "string" ? value : undefined;
}

function encodeOAuthState(redirectUri: string, nonce: string): string {
  return Buffer.from(JSON.stringify({ redirectUri, nonce }), "utf8").toString("base64");
}

function decodeOAuthState(state: string): { redirectUri: string; nonce: string } | null {
  if (state.length > 4096) return null;
  try {
    const decoded: unknown = JSON.parse(Buffer.from(state, "base64").toString("utf8"));
    if (!decoded || typeof decoded !== "object") return null;
    const value = decoded as Record<string, unknown>;
    if (typeof value.redirectUri !== "string" || typeof value.nonce !== "string") return null;
    if (value.redirectUri.length > 2048 || !/^[A-Za-z0-9_-]{32,128}$/.test(value.nonce)) return null;
    return { redirectUri: value.redirectUri, nonce: value.nonce };
  } catch { return null; }
}

function isAllowedRedirect(req: Request, redirectUri: string, client: OAuthClient): boolean {
  try {
    const url = new URL(redirectUri);
    if (client === "web") {
      const origin = req.get("origin");
      return Boolean(origin) && url.origin === new URL(origin!).origin && url.pathname === "/oauth/callback" && !url.search && !url.hash;
    }
    return url.protocol === `${NATIVE_OAUTH_SCHEME}:` && url.hostname === "oauth" && url.pathname === "/callback" && !url.search && !url.hash;
  } catch { return false; }
}

function cookieStateOptions(req: Request) {
  return { ...getSessionCookieOptions(req), maxAge: OAUTH_STATE_TTL_MS };
}

function issueOAuthState(req: Request, res: Response, redirectUri: string, client: OAuthClient): string | null {
  if (!isAllowedRedirect(req, redirectUri, client)) return null;
  const now = Date.now();
  for (const [nonce, pending] of pendingStates) if (pending.expiresAt <= now) pendingStates.delete(nonce);
  if (pendingStates.size >= MAX_PENDING_STATES) return null;
  const nonce = randomBytes(32).toString("base64url");
  pendingStates.set(nonce, { client, nonce, redirectUri, expiresAt: now + OAUTH_STATE_TTL_MS });
  if (client === "web") res.cookie(getOAuthStateCookieName(req), nonce, cookieStateOptions(req));
  return encodeOAuthState(redirectUri, nonce);
}

function consumeOAuthState(
  req: Request,
  res: Response,
  state: string,
  allowedClient: OAuthClient | "either",
): boolean {
  const parsed = decodeOAuthState(state);
  if (!parsed) return false;
  const pending = pendingStates.get(parsed.nonce);
  if (!pending || pending.expiresAt <= Date.now()) {
    pendingStates.delete(parsed.nonce);
    return false;
  }
  if (pending.redirectUri !== parsed.redirectUri || (allowedClient !== "either" && pending.client !== allowedClient)) return false;
  if (pending.client === "web" && getCookieValue(req, getOAuthStateCookieName(req)) !== pending.nonce) return false;
  pendingStates.delete(pending.nonce);
  if (pending.client === "web") res.clearCookie(getOAuthStateCookieName(req), cookieStateOptions(req));
  return true;
}

async function syncUser(userInfo: {
  openId?: string | null;
  name?: string | null;
  email?: string | null;
  loginMethod?: string | null;
  platform?: string | null;
}) {
  if (!userInfo.openId) throw new Error("openId missing from user info");
  const lastSignedIn = new Date();
  await upsertUser({
    openId: userInfo.openId,
    name: userInfo.name || null,
    email: userInfo.email ?? null,
    loginMethod: userInfo.loginMethod ?? userInfo.platform ?? null,
    lastSignedIn,
  });
  const saved = await getUserByOpenId(userInfo.openId);
  return saved ?? {
    openId: userInfo.openId,
    name: userInfo.name,
    email: userInfo.email,
    loginMethod: userInfo.loginMethod ?? null,
    lastSignedIn,
  };
}

function buildUserResponse(
  user: Awaited<ReturnType<typeof getUserByOpenId>> | {
    openId: string; name?: string | null; email?: string | null; loginMethod?: string | null; lastSignedIn?: Date | null;
  },
) {
  return {
    id: (user as any)?.id ?? null,
    openId: user?.openId ?? null,
    name: user?.name ?? null,
    email: user?.email ?? null,
    loginMethod: user?.loginMethod ?? null,
    lastSignedIn: (user?.lastSignedIn ?? new Date()).toISOString(),
  };
}

export function registerOAuthRoutes(app: Express) {
  app.post("/api/oauth/state", (req: Request, res: Response) => {
    const { redirectUri, client } = req.body ?? {};
    if (typeof redirectUri !== "string" || (client !== "web" && client !== "native")) {
      res.status(400).json({ error: "تعذّر بدء تسجيل الدخول؛ أعد فتح شاشة الدخول." });
      return;
    }
    const state = issueOAuthState(req, res, redirectUri, client);
    if (!state) {
      res.status(400).json({ error: "رابط العودة إلى التطبيق غير صالح أو انتهت مهلة الدخول." });
      return;
    }
    res.setHeader("Cache-Control", "no-store");
    res.json({ state });
  });

  // Compatibility callback for a provider configured to return to the API host.
  // New app flows return to the frontend's fixed /oauth/callback route instead.
  app.get("/api/oauth/callback", async (req: Request, res: Response) => {
    const code = getQueryParam(req, "code");
    const state = getQueryParam(req, "state");
    if (!code || !state || !consumeOAuthState(req, res, state, "web")) {
      res.status(400).json({ error: "طلب الدخول غير صالح أو انتهت مهلته. ابدأ الدخول من التطبيق مجددًا." });
      return;
    }
    try {
      const tokenResponse = await sdk.exchangeCodeForToken(code, state);
      const userInfo = await sdk.getUserInfo(tokenResponse.accessToken);
      await syncUser(userInfo);
      const sessionToken = await sdk.createSessionToken(userInfo.openId!, { name: userInfo.name || "", expiresInMs: ONE_YEAR_MS });
      res.cookie(getSessionCookieName(req), sessionToken, { ...getSessionCookieOptions(req), maxAge: ONE_YEAR_MS });
      const frontendUrl = process.env.EXPO_WEB_PREVIEW_URL || process.env.EXPO_PACKAGER_PROXY_URL || "http://localhost:8081";
      res.redirect(302, frontendUrl);
    } catch {
      console.error("[OAuth] Callback failed");
      res.status(500).json({ error: "OAuth callback failed" });
    }
  });

  app.post("/api/oauth/mobile", async (req: Request, res: Response) => {
    const code = typeof req.body?.code === "string" ? req.body.code : undefined;
    const state = typeof req.body?.state === "string" ? req.body.state : undefined;
    if (!code || !state || !consumeOAuthState(req, res, state, "either")) {
      res.status(400).json({ error: "طلب الدخول غير صالح أو انتهت مهلته. ابدأ الدخول من التطبيق مجددًا." });
      return;
    }
    try {
      const tokenResponse = await sdk.exchangeCodeForToken(code, state);
      const userInfo = await sdk.getUserInfo(tokenResponse.accessToken);
      const user = await syncUser(userInfo);
      const sessionToken = await sdk.createSessionToken(userInfo.openId!, { name: userInfo.name || "", expiresInMs: ONE_YEAR_MS });
      res.cookie(getSessionCookieName(req), sessionToken, { ...getSessionCookieOptions(req), maxAge: ONE_YEAR_MS });
      res.setHeader("Cache-Control", "no-store");
      res.json({ app_session_id: sessionToken, user: buildUserResponse(user) });
    } catch {
      console.error("[OAuth] Mobile exchange failed");
      res.status(500).json({ error: "OAuth mobile exchange failed" });
    }
  });

  app.post("/api/auth/logout", (req: Request, res: Response) => {
    res.clearCookie(getSessionCookieName(req), { ...getSessionCookieOptions(req), maxAge: -1 });
    res.json({ success: true });
  });

  app.get("/api/auth/me", async (req: Request, res: Response) => {
    const authorization = req.headers.authorization;
    const bearerToken = typeof authorization === "string" && authorization.startsWith("Bearer ")
      ? authorization.slice("Bearer ".length).trim()
      : "";
    const sessionCookie = getCookieValue(req, getSessionCookieName(req));
    if (!bearerToken && !sessionCookie) {
      res.status(401).json({ error: "Not authenticated", user: null });
      return;
    }
    try {
      const user = await sdk.authenticateRequest(req);
      res.json({ user: buildUserResponse(user) });
    } catch (error) {
      const expectedAuthRejection = error instanceof HttpError
        && error.statusCode === 403
        && error.message !== "Failed to sync user info";
      if (!expectedAuthRejection) console.error("[Auth] /api/auth/me failed");
      res.status(401).json({ error: "Not authenticated", user: null });
    }
  });

  app.post("/api/auth/session", async (req: Request, res: Response) => {
    try {
      const user = await sdk.authenticateRequest(req);
      const authHeader = req.headers.authorization || req.headers.Authorization;
      if (typeof authHeader !== "string" || !authHeader.startsWith("Bearer ")) {
        res.status(400).json({ error: "Bearer token required" });
        return;
      }
      const token = authHeader.slice("Bearer ".length).trim();
      res.cookie(getSessionCookieName(req), token, { ...getSessionCookieOptions(req), maxAge: ONE_YEAR_MS });
      res.json({ success: true, user: buildUserResponse(user) });
    } catch {
      console.error("[Auth] /api/auth/session failed");
      res.status(401).json({ error: "Invalid token" });
    }
  });
}
