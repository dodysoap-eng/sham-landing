import { afterEach, describe, expect, it } from "vitest";
import type { Request } from "express";
import { getOAuthStateCookieName, getSessionCookieOptions } from "../server/_core/cookies";

const preview = process.env.EXPO_WEB_PREVIEW_URL;
const api = process.env.EXPO_PUBLIC_API_BASE_URL;
const packager = process.env.EXPO_PACKAGER_PROXY_URL;
afterEach(() => {
  if (preview === undefined) delete process.env.EXPO_WEB_PREVIEW_URL; else process.env.EXPO_WEB_PREVIEW_URL = preview;
  if (api === undefined) delete process.env.EXPO_PUBLIC_API_BASE_URL; else process.env.EXPO_PUBLIC_API_BASE_URL = api;
  if (packager === undefined) delete process.env.EXPO_PACKAGER_PROXY_URL; else process.env.EXPO_PACKAGER_PROXY_URL = packager;
});

function request(protocol: string, headers: Record<string, string> = {}) {
  return { protocol, headers, hostname: "localhost" } as unknown as Request;
}

describe("كوكي الجلسة والمعاينة", () => {
  it("يضبط SameSite=None وSecure إذا أكد الوكيل HTTPS", () => {
    delete process.env.EXPO_WEB_PREVIEW_URL;
    delete process.env.EXPO_PUBLIC_API_BASE_URL;
    delete process.env.EXPO_PACKAGER_PROXY_URL;
    const options = getSessionCookieOptions(request("http", { "x-forwarded-proto": "http, https" }));
    expect(options.sameSite).toBe("none");
    expect(options.secure).toBe(true);
    expect(options.httpOnly).toBe(true);
  });

  it("يتعرف على HTTPS العام حتى إن وصل الطلب إلى التطبيق داخليًا عبر HTTP", () => {
    process.env.EXPO_WEB_PREVIEW_URL = "https://preview.example.test";
    delete process.env.EXPO_PUBLIC_API_BASE_URL;
    delete process.env.EXPO_PACKAGER_PROXY_URL;
    const req = request("http");
    const options = getSessionCookieOptions(req);
    expect(options.sameSite).toBe("none");
    expect(options.secure).toBe(true);
    expect(getOAuthStateCookieName(req)).toBe("__Host-sham_oauth_state");
  });

  it("يبقي HTTP المحلي صالحًا دون Secure عند غياب أصل HTTPS", () => {
    delete process.env.EXPO_WEB_PREVIEW_URL;
    delete process.env.EXPO_PUBLIC_API_BASE_URL;
    delete process.env.EXPO_PACKAGER_PROXY_URL;
    const options = getSessionCookieOptions(request("http"));
    expect(options.sameSite).toBe("lax");
    expect(options.secure).toBe(false);
    expect(getOAuthStateCookieName(request("http"))).toBe("sham_local_oauth_state");
  });
});
