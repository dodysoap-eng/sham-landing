import { describe, expect, it } from "vitest";
import { calculateFormula, createBlankFormula, type FormulaIngredient } from "../lib/sham-domain";

function ingredient(patch: Partial<FormulaIngredient> = {}): FormulaIngredient {
  return { id: "row-1", name: "مكوّن اختباري", amount: 1, ifraStatus: "unknown", ...patch };
}

describe("حساب التركيبة في شم", () => {
  it("يوزّع أجزاء الوزن داخل المركز ثم يحسب المذيب منفصلًا", () => {
    const formula = { ...createBlankFormula(), inputMode: "parts" as const, targetBatchGrams: 100, concentrationPercent: 20, ingredients: [ingredient({ amount: 1 }), ingredient({ id: "row-2", name: "ثانٍ", amount: 3 })] };
    const result = calculateFormula(formula);
    expect(result.totalInput).toBe(4);
    expect(result.concentrateGrams).toBe(20);
    expect(result.carrierGrams).toBe(80);
    expect(result.rows.map((row) => row.grams)).toEqual([5, 15]);
    expect(result.valid).toBe(true);
  });

  it("لا يعتبر مدخل النسب مكتملًا قبل بلوغ 100٪", () => {
    const result = calculateFormula({ ...createBlankFormula(), inputMode: "percent", ingredients: [ingredient({ amount: 70 })] });
    expect(result.valid).toBe(false);
    expect(result.warnings.some((warning) => warning.includes("100٪"))).toBe(true);
  });

  it("يقارن IFRA Cat 4 بالحد المدخل فقط ولا يطبق الفحص على فئات أخرى", () => {
    const base = { ...createBlankFormula(), inputMode: "percent" as const, concentrationPercent: 20, ingredients: [ingredient({ amount: 100, ifraStatus: "documented", ifraMaxPercent: 10, ifraSource: "test record" })] };
    expect(calculateFormula(base).ifra[0]?.status).toBe("over");
    expect(calculateFormula({ ...base, productCategory: "candle" }).ifra[0]?.status).toBe("not_applicable");
  });

  it("يصف الأسواق غير المدخلة بأنها غير مقيمة ولا يخترع حدًا", () => {
    const result = calculateFormula({ ...createBlankFormula(), inputMode: "percent", markets: ["eg"], ingredients: [ingredient({ amount: 100 })] });
    expect(result.marketChecks[0]?.status).toBe("unknown");
    expect(result.warnings.some((warning) => warning.includes("لا يعني ذلك عدم وجود قيود"))).toBe(true);
  });

  it("يحسب تكلفة الخام من الجرامات ويفصل العملات المختلفة بدل جمعها", () => {
    const base = { ...createBlankFormula(), inputMode: "percent" as const, targetBatchGrams: 1000, concentrationPercent: 20, ingredients: [ingredient({ amount: 100, costPerKg: 100, currency: "EGP" })] };
    const single = calculateFormula(base);
    expect(single.rawCostTotal).toBe(20);
    expect(single.rawCostCurrency).toBe("EGP");
    const mixed = calculateFormula({ ...base, ingredients: [base.ingredients[0]!, ingredient({ id: "row-2", amount: 0, costPerKg: 10, currency: "USD" })] });
    expect(mixed.rawCostCurrency).toBeNull();
    expect(mixed.rawCostTotal).toBeNull();
  });
});
