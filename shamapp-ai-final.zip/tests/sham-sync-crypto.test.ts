import { beforeEach, describe, expect, it, vi } from "vitest";

vi.mock("expo-crypto", () => {
  let seed = 1;
  return { getRandomBytesAsync: async (length: number) => Uint8Array.from({ length }, () => (seed++ % 255) + 1) };
});

import { createBlankFormula, createEmptyWorkspace } from "../lib/sham-domain";
import {
  createCloudSalt,
  decryptLocalWorkspace,
  decryptWorkspace,
  deriveCloudKey,
  encryptLocalWorkspace,
  encryptWorkspace,
  validateWorkspacePayload,
  validateRecoveryPhrase,
} from "../lib/sham-sync-crypto";

describe("تشفير مساحة شم", () => {
  const openId = "account-a";
  const key = new Uint8Array(32).fill(19);
  beforeEach(() => { vi.clearAllMocks(); });

  it("يشفر نسخة السحابة قبل الرفع ويستعيدها للحساب المصرح نفسه", async () => {
    const workspace = { ...createEmptyWorkspace(), formulas: [{ ...createBlankFormula(), id: "f1", title: "ورد", ingredients: [{ id: "r1", name: "ورد", amount: 1, ifraStatus: "unknown" as const }] }] };
    const salt = await createCloudSalt();
    const encrypted = await encryptWorkspace(workspace, key, salt, openId);
    expect(encrypted.type).toBe("sham.workspace.aes-gcm.v1");
    expect(encrypted.ciphertext).not.toContain("ورد");
    expect(decryptWorkspace(encrypted, key, openId)).toEqual(workspace);
  });

  it("يرفض مفتاحًا خاطئًا أو نقل الحمولة إلى حساب آخر أو تغيير الوسم", async () => {
    const workspace = createEmptyWorkspace();
    const envelope = await encryptWorkspace(workspace, key, await createCloudSalt(), openId);
    expect(() => decryptWorkspace(envelope, new Uint8Array(32).fill(20), openId)).toThrow();
    expect(() => decryptWorkspace(envelope, key, "account-b")).toThrow();
    const last = envelope.ciphertext.at(-1) === "0" ? "1" : "0";
    expect(() => decryptWorkspace({ ...envelope, ciphertext: envelope.ciphertext.slice(0, -1) + last }, key, openId)).toThrow();
  });

  it("يشفر مساحة الجهاز كذلك قبل AsyncStorage", async () => {
    const workspace = createEmptyWorkspace();
    const envelope = await encryptLocalWorkspace(workspace, key, openId);
    expect(envelope.ciphertext).not.toContain("schemaVersion");
    expect(decryptLocalWorkspace(envelope, key, openId)).toEqual(workspace);
  });

  it("يرفض سجلات غير صالحة داخل تركيبات أو مواد أو جلسات مشفرة", () => {
    const base = createEmptyWorkspace();
    const formula = createBlankFormula();
    expect(validateWorkspacePayload({ ...base, formulas: [formula] })).toBe(true);
    expect(validateWorkspacePayload({ ...base, updatedAt: "" })).toBe(false);
    expect(validateWorkspacePayload({ ...base, updatedAt: "x".repeat(81) })).toBe(false);
    expect(validateWorkspacePayload({ ...base, updatedAt: "not-a-timestamp" })).toBe(false);
    expect(validateWorkspacePayload({ ...base, formulas: [null] })).toBe(false);
    expect(validateWorkspacePayload({ ...base, formulas: [{ ...formula, ingredients: [null] }] })).toBe(false);
    expect(validateWorkspacePayload({ ...base, ingredients: [{ id: "m1", name: "مادة", ifraStatus: "documented", costPerKg: Number.NaN }] })).toBe(false);
    expect(validateWorkspacePayload({ ...base, sessions: [{ id: "s1", title: "جلسة", notes: "", status: "unknown", updatedAt: new Date().toISOString() }] })).toBe(false);
  });

  it("يرفض حمولة مشوهة أو تتجاوز الحد قبل تشفيرها للسحابة", async () => {
    const salt = await createCloudSalt();
    const invalid = { ...createEmptyWorkspace(), formulas: [null] } as never;
    await expect(encryptWorkspace(invalid, key, salt, openId)).rejects.toThrow(/غير صالح/);
    const oversized = { ...createEmptyWorkspace(), ingredients: Array.from({ length: 2_001 }, (_, index) => ({ id: `m${index}`, name: "مادة", ifraStatus: "unknown" as const })) };
    await expect(encryptWorkspace(oversized, key, salt, openId)).rejects.toThrow(/غير صالح/);
  });

  it("يشتق مفتاحًا حتميًا من عبارة الاسترداد والملح ولا يقبل عبارة قصيرة", async () => {
    const salt = await createCloudSalt();
    const first = await deriveCloudKey("عبارة سرية طويلة 2026", salt);
    const second = await deriveCloudKey("عبارة سرية طويلة 2026", salt);
    expect(Array.from(first)).toEqual(Array.from(second));
    expect(validateRecoveryPhrase("قصيرة")).toMatch(/16/);
    expect(validateRecoveryPhrase("عبارة استرداد صالحة وطويلة")).toBeNull();
  });
});
