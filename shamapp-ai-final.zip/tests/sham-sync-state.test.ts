import { describe, expect, it } from "vitest";
import { createBlankFormula, createEmptyWorkspace } from "../lib/sham-domain";
import { decideSyncAction, shouldKeepPendingAfterDisable } from "../lib/sham-sync-state";
import type { WorkspaceData } from "../lib/sham-domain";

function withFormula(title: string): WorkspaceData {
  const base = createEmptyWorkspace();
  const formula = { ...createBlankFormula(), id: title, title };
  return { ...base, formulas: [formula] };
}

describe("قرار مزامنة شم", () => {
  it("يرفع التغييرات المعلقة إذا لم تتغير مراجعة الخادم", () => {
    expect(decideSyncAction({ local: withFormula("محلي"), remote: withFormula("قديم"), remoteRevision: 7, baseRevision: 7, pending: true })).toBe("upload-local");
  });

  it("يعيد رفع snapshot محلي مختلف إذا توقف التطبيق قبل حفظ pending", () => {
    expect(decideSyncAction({ local: withFormula("محلي الأحدث"), remote: withFormula("آخر نسخة متزامنة"), remoteRevision: 7, baseRevision: 7, pending: false })).toBe("upload-local");
  });

  it("لا يستبدل نسخة جهاز متعارضة عندما تتغير مراجعة الخادم", () => {
    expect(decideSyncAction({ local: withFormula("محلي"), remote: withFormula("سحابي"), remoteRevision: 8, baseRevision: 7, pending: true })).toBe("conflict");
  });

  it("يعتمد النسخة السحابية الأحدث إذا لم تكن هناك تغييرات محلية معلقة", () => {
    expect(decideSyncAction({ local: withFormula("قديم"), remote: withFormula("حديث"), remoteRevision: 8, baseRevision: 7, pending: false })).toBe("adopt-cloud");
  });

  it("يتعرف على حفظ سبق أن قبله الخادم لكن ضاع رده، دون إنشاء تعارض زائف", () => {
    const saved = withFormula("متطابق");
    expect(decideSyncAction({ local: saved, remote: saved, remoteRevision: 8, baseRevision: 7, pending: true })).toBe("adopt-cloud");
  });

  it("يرفع حذف آخر سجل كحمولة فارغة بدل استعادته من السحابة", () => {
    expect(decideSyncAction({ local: createEmptyWorkspace(), remote: withFormula("محذوف"), remoteRevision: 7, baseRevision: 7, pending: true })).toBe("upload-local");
  });

  it("يعرض حذفًا سحابيًا أحدث كتعارض بدل محو بيانات الجهاز", () => {
    expect(decideSyncAction({ local: withFormula("نسخة الجهاز"), remote: createEmptyWorkspace(), remoteRevision: 8, baseRevision: 7, pending: false })).toBe("conflict");
  });

  it("لا يرفع بيانات الجهاز فوق حذف سحابي إذا تغيّرت المراجعة أثناء إعادة التفعيل", () => {
    expect(decideSyncAction({ local: withFormula("نسخة الجهاز"), remote: createEmptyWorkspace(), remoteRevision: 8, baseRevision: 7, pending: true })).toBe("conflict");
  });

  it("يرفع بيانات محلية معلقة مقابل النسخة السحابية الفارغة عبر CAS المطابق فقط", () => {
    expect(decideSyncAction({ local: withFormula("النسخة الجديدة"), remote: createEmptyWorkspace(), remoteRevision: 7, baseRevision: 7, pending: true })).toBe("upload-local");
  });

  it("يعرض حذف النسخة السحابية بعد مراجعة سابقة كتعارضًا", () => {
    expect(decideSyncAction({ local: withFormula("نسخة الجهاز"), remote: null, remoteRevision: 0, baseRevision: 7, pending: false })).toBe("conflict");
  });

  it("لا يعيد إنشاء سجل حُذف من السحابة دون مراجعة pending مطابقة", () => {
    expect(decideSyncAction({ local: withFormula("نسخة قديمة"), remote: null, remoteRevision: 0, baseRevision: null, pending: true })).toBe("conflict");
    expect(decideSyncAction({ local: withFormula("نسخة قديمة"), remote: null, remoteRevision: 0, baseRevision: 0, pending: false })).toBe("conflict");
    expect(decideSyncAction({ local: withFormula("نسخة أحدث"), remote: null, remoteRevision: 0, baseRevision: 0, pending: true })).toBe("upload-local");
  });

  it("يطلب اختيارًا صريحًا لترحيل local v1 حتى إذا تطابقت النسختان", () => {
    const same = withFormula("نسخة قديمة");
    expect(decideSyncAction({ local: same, remote: same, remoteRevision: 1, baseRevision: 1, pending: false, localIsLegacy: true })).toBe("conflict");
  });

  it("لا يرفع local v1 تلقائيًا عندما تكون السحابة فارغة", () => {
    expect(decideSyncAction({ local: withFormula("نسخة قديمة"), remote: null, remoteRevision: 0, baseRevision: null, pending: true, localIsLegacy: true })).toBe("conflict");
  });

  it("يطلب اختيارًا صريحًا عند وجود cloud v1 حتى إذا تطابقت بياناتها", () => {
    const same = withFormula("نسخة قديمة");
    expect(decideSyncAction({ local: same, remote: same, remoteRevision: 1, baseRevision: 1, pending: false, remoteIsLegacy: true })).toBe("conflict");
  });

  it("لا يستعيد السحابة تلقائيًا فوق حذف محلي معلّق بعد تعطيل المزامنة", () => {
    expect(decideSyncAction({ local: createEmptyWorkspace(), remote: withFormula("السحابة"), remoteRevision: 8, baseRevision: 7, pending: true })).toBe("conflict");
  });

  it("يحمي الحذف المحلي المعروف حتى إذا فُقدت علامة pending القديمة", () => {
    expect(decideSyncAction({ local: createEmptyWorkspace(), remote: withFormula("السحابة"), remoteRevision: 8, baseRevision: 7, pending: false })).toBe("conflict");
  });

  it("يعرض اختيارًا صريحًا عندما تختلف مساحة محلية فارغة عن السحابة بلا مراجعة", () => {
    expect(decideSyncAction({ local: createEmptyWorkspace(), remote: withFormula("السحابة"), remoteRevision: 8, baseRevision: null, pending: false })).toBe("conflict");
  });

  it("يستعيد السحابة تلقائيًا فقط عندما لا توجد لقطة محلية أصلًا", () => {
    expect(decideSyncAction({ local: null, remote: withFormula("السحابة"), remoteRevision: 8, baseRevision: null, pending: false })).toBe("adopt-cloud");
  });

  it("يبقي طابور التغييرات المعلقة عند إيقاف المزامنة", () => {
    expect(shouldKeepPendingAfterDisable(true)).toBe(true);
    expect(shouldKeepPendingAfterDisable(false)).toBe(false);
  });
});
