import { describe, expect, it } from "vitest";
import { decodeUtf8, encodeUtf8 } from "../lib/sham-utf8";

describe("UTF-8 المحمول لـAndroid Hermes", () => {
  it("يحوّل النص العربي والرموز ونصوص INCI ذهابًا وإيابًا", () => {
    const input = "شم 🌿 — Rose absolute / ورد";
    expect(decodeUtf8(encodeUtf8(input))).toBe(input);
  });

  it("يرفض سلاسل UTF-8 المبتورة وغير القانونية بدل إنتاج محتوى صامت مختلف", () => {
    expect(() => decodeUtf8(Uint8Array.from([0xe2, 0x82]))).toThrow();
    expect(() => decodeUtf8(Uint8Array.from([0xc0, 0xaf]))).toThrow();
  });
});
