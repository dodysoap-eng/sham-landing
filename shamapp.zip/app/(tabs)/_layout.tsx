import { Redirect, Tabs } from "expo-router";
import { ActivityIndicator, View, type ColorValue } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { useAuth } from "@/hooks/use-auth";
import { ShamWorkspaceProvider } from "@/lib/sham-workspace-context";
import { Brand } from "@/constants/brand";
import { HapticTab } from "@/components/haptic-tab";

export default function TabLayout() {
  const { user, loading } = useAuth();
  if (loading) return <View style={{ flex: 1, backgroundColor: Brand.colors.canvas, alignItems: "center", justifyContent: "center" }}><ActivityIndicator color={Brand.colors.forest} /></View>;
  if (!user?.openId) return <Redirect href="/login" />;
  const icon = (name: keyof typeof Ionicons.glyphMap) => {
    function TabIcon({ color }: { color: ColorValue }) {
      return <Ionicons name={name} size={21} color={color} />;
    }
    return TabIcon;
  };
  return (
    <ShamWorkspaceProvider key={user.openId} openId={user.openId}>
      <Tabs screenOptions={{
        headerShown: false,
        tabBarButton: HapticTab,
        tabBarActiveTintColor: Brand.colors.forest,
        tabBarInactiveTintColor: Brand.colors.muted,
        tabBarLabelStyle: { fontSize: 10, fontWeight: "700", marginTop: 1 },
        tabBarStyle: { backgroundColor: Brand.colors.paper, borderTopColor: Brand.colors.line, borderTopWidth: 1, height: 62, paddingTop: 6, paddingBottom: 6 },
      }}>
        <Tabs.Screen name="index" options={{ title: "اليوم", tabBarIcon: icon("home-outline") }} />
        <Tabs.Screen name="calculator" options={{ title: "الحاسبة", tabBarIcon: icon("flask-outline") }} />
        <Tabs.Screen name="library" options={{ title: "المكتبة", tabBarIcon: icon("library-outline") }} />
        <Tabs.Screen name="assistant" options={{ title: "المساعد", tabBarIcon: icon("chatbubble-ellipses-outline") }} />
        <Tabs.Screen name="account" options={{ href: null }} />
      </Tabs>
    </ShamWorkspaceProvider>
  );
}
